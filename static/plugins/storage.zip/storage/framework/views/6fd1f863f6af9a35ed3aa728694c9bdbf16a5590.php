<div class="col-md-9">
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Thông tin Bất động sản</h3>
            <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i
                        class="fas fa-minus"></i>
                </button>
            </div>
        </div>
        <!-- /.card-header -->
        <div class="card-body">
            <div class="row">
                <div class="col-md-12 form-group">
                    <label for="">Tiêu đề bài rao</label>
                    <input
                    id="title"
                    type="text"
                    class="form-control "
                    name="title"
                    placeholder="Tiêu đề bài rao"
                    <?php if(isset($realty_post)): ?>
                    value="<?php echo e($realty_post->title ?? ''); ?>"
                    <?php endif; ?>
                    >
                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div id="" class="error invalid-feedback d-block">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-12 form-group">
                    <label for="">Slug</label>
                    <input
                    id="slug"
                    type="text"
                    class="form-control "
                    name="slug"
                    placeholder="Slug"
                    <?php if(isset($realty_post)): ?>
                    value="<?php echo e($realty_post->slug ?? ''); ?>"
                    <?php endif; ?>
                    >
                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div id="" class="error invalid-feedback d-block">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6 form-group">
                    <label for="realty_post_type">Loại hình giao dịch (<span class="text-red">*</span>)</label>
                    <select class="form-control" name="realty_post_type" id="realty_post_type">
                        <option value="1" <?php if(isset($realty_post) && $realty_post->type == 1): ?> selected <?php endif; ?> >Bán</option>
                        <option value="2" <?php if(isset($realty_post) && $realty_post->type == 2): ?> selected <?php endif; ?> >Cho thuê</option>
                    </select>
                </div>
                <div class="col-md-6 form-group">
                    <label for="realty_type">Loại hình bất động sản (<span class="text-red">*</span>)</label>
                    <select class="form-control" name="realty_type" id="realty_type">
                        <option value="1" <?php if(isset($realty) && $realty->type == 1): ?> selected <?php endif; ?> >Chung cư/ Căn hộ</option>
                        <option value="2" <?php if(isset($realty) && $realty->type == 2): ?> selected <?php endif; ?> >Nhà riêng</option>
                        <option value="3" <?php if(isset($realty) && $realty->type == 3): ?> selected <?php endif; ?> >Đất nền</option>
                    </select>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6 form-group">
                    <label for="area">Diện tích (<span class="text-red">*</span>)</label>
                    <input
                    name="area"
                    type="number"
                    class="form-control <?php $__errorArgs = ['area'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    id="area"
                    placeholder="Nhập diện tích BDS"
                    value="<?php echo e($realty_post->realty->area ?? old('area')); ?>"
                    >
                    <?php $__errorArgs = ['area'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div id="" class="error invalid-feedback d-block">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-6 form-group">
                    <label for="direction">Hướng (<span class="text-red">*</span>)</label>
                    <select class="form-control" id="direction" name="direction">
                        <option value="">Hướng</option>
                        <option value="1" <?php if(isset($realty) && $realty->direction == 1): ?> selected <?php endif; ?> >Đông</option>
                        <option value="2" <?php if(isset($realty) && $realty->direction == 2): ?> selected <?php endif; ?> >Tây</option>
                        <option value="3" <?php if(isset($realty) && $realty->direction == 3): ?> selected <?php endif; ?> >Nam</option>
                        <option value="4" <?php if(isset($realty) && $realty->direction == 4): ?> selected <?php endif; ?> >Bắc</option>
                        <option value="5" <?php if(isset($realty) && $realty->direction == 5): ?> selected <?php endif; ?> >Đông Bắc</option>
                        <option value="6" <?php if(isset($realty) && $realty->direction == 6): ?> selected <?php endif; ?> >Đông Nam</option>
                        <option value="7" <?php if(isset($realty) && $realty->direction == 7): ?> selected <?php endif; ?> >Tây Bắc</option>
                        <option value="8" <?php if(isset($realty) && $realty->direction == 8): ?> selected <?php endif; ?> >Tây Nam</option>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label for="price">Giá(<span class="text-red">*</span>)</label>
                <input
                name="price"
                type="number"
                class="form-control <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                id="price"
                placeholder="Nhập giá bất động sản"
                value="<?php echo e($realty_post->price ?? old('price')); ?>"
                >
                <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div id="" class="error invalid-feedback d-block">
                        <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="row">
                <div class="col-12"><label>Địa chỉ BĐS</label></div>
                <div class="col-md-4 form-group">
                    <select class="form-control address_input" name="province" id="province">
                        <option value="">Tỉnh/Thành phố</option>
                        <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option
                        <?php if(isset($realty) && $province->code == $realty->province_code): ?> selected <?php endif; ?>
                        value="<?php echo e($province->code); ?>"><?php echo e($province->name_with_type); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-4 form-group">
                    <select class="form-control address_input" name="district" id="district">
                        <option value="0">Huyện/Thị xã</option>
                        <?php if(isset($districts)): ?>
                            <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option
                            <?php if($district->code == $realty->district_code): ?> selected <?php endif; ?>
                            value="<?php echo e($district->code); ?>"><?php echo e($district->name_with_type); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="col-md-4 form-group">
                    <select class="form-control address_input" name="commune" id="commune">
                        <option value="0">Xã/ Phường</option>
                        <?php if(isset($communes)): ?>
                        <?php $__currentLoopData = $communes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commune): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option
                        <?php if($commune->code == $realty->commune_code): ?> selected <?php endif; ?>
                        value="<?php echo e($commune->code); ?>"><?php echo e($commune->name_with_type); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                </div>
            </div>

            <div class="row">
                <div class="col-md-4 form-group">
                    <input
                    <?php if(isset($realty)): ?>
                    value="<?php echo e($realty->apartment_number ?? old('apartment_number')); ?>"
                    <?php endif; ?>
                    type="text" name="apartment_number" class="form-control" placeholder="Số nhà">
                </div>

                <div class="col-md-8 form-group">
                    <input
                    type="text"
                    class="form-control address_input"
                    name="street"
                    placeholder="Địa chỉ cụ thể"
                    <?php if(isset($realty)): ?>
                    value="<?php echo e($realty->street ?? ''); ?>"
                    <?php endif; ?>
                    >
                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div id="" class="error invalid-feedback d-block">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="row">
                <div class="map-container mx-auto col-12" style="padding:20px">
                    <div id="map" style="width: 100%; height:500px"></div>
                </div>
                <input type="hidden" name="google_map_lat">
                <input type="hidden" name="google_map_lng">
            </div>


            <div class="form-group">
                <label>Mô tả ngắn</label>
                <textarea name="description" class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="3"
                    placeholder="Nhập mô tả ..."><?php echo e($realty_post->description ?? old('description')); ?></textarea>
                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div id="" class="error invalid-feedback d-block">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label>Hình ảnh nhà</label>
                <?php echo $__env->make('components.dropzone_upload', [
                    'input_name' => 'house_image',
                    'mock_file' => $house_image ?? null,
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php $__errorArgs = ['house_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div id="" class="error invalid-feedback d-block">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label>Bản vẽ và sơ đồ</label>
                <?php echo $__env->make('components.dropzone_upload', [
                    'input_name' => 'house_design_image',
                    'mock_file' => $house_design_image ?? null,
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php $__errorArgs = ['house_design_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div id="" class="error invalid-feedback d-block">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <!-- /.card-body -->
    </div>
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Thông tin liên hệ</h3>
            <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i
                        class="fas fa-minus"></i>
                </button>
            </div>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6 form-group">
                    <label>Tên người dùng</label>
                    <input
                    type="text"
                    class="form-control"
                    name="contact_name"
                    placeholder="Tên người dùng"
                    <?php if(isset($realty_post)): ?>
                    value="<?php echo e($realty_post->contact_name ?? ''); ?>"
                    <?php endif; ?>
                    >
                    <?php $__errorArgs = ['contact_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div id="" class="error invalid-feedback d-block">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>
                <div class="col-md-6 form-group">
                    <label>Số điện thoại</label>
                    <input
                    type="text"
                    class="form-control"
                    name="contact_phone_number"
                    placeholder="Số điện thoại"
                    <?php if(isset($realty_post)): ?>
                    value="<?php echo e($realty_post->contact_phone_number ?? ''); ?>"
                    <?php endif; ?>
                    >
                    <?php $__errorArgs = ['contact_phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div id="" class="error invalid-feedback d-block">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="form-group">
                <label>Email liên hệ</label>
                <input
                type="text"
                class="form-control"
                name="contact_email"
                placeholder="Email"
                <?php if(isset($realty_post)): ?>
                value="<?php echo e($realty_post->contact_email ?? ''); ?>"
                <?php endif; ?>
                >
                <?php $__errorArgs = ['contact_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div id="" class="error invalid-feedback d-block">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>
            <div class="form-group">
                <label>Địa chỉ</label>
                <input
                type="text"
                class="form-control"
                name="contact_address"
                placeholder="Nhập địa chỉ"
                <?php if(isset($realty_post)): ?>
                value="<?php echo e($realty_post->contact_address ?? ''); ?>"
                <?php endif; ?>
                >
                <?php $__errorArgs = ['contact_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div id="" class="error invalid-feedback d-block">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>
        </div>
    </div>
</div>
<div class="col-md-3">

    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Thao tác</h3>
            <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i
                        class="fas fa-minus"></i>
                </button>
            </div>
        </div>
        <div class="card-body">
            <div class="btn-set">
                <button type="submit" name="submit" value="save" class="btn btn-info">
                    <i class="fa fa-save"></i> Lưu
                </button>
                &nbsp;
                <button type="submit" name="submit" value="apply" class="btn btn-success">
                    <i class="fa fa-check-circle"></i> Lưu &amp; Thoát
                </button>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Trạng thái </h3>
            <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i
                        class="fas fa-minus"></i>
                </button>
            </div>
        </div>

        <div class="card-body">
            <div class="form-group">
                <label>Trạng thái</label>
                <select class="form-control select2 select2-info" value="" name="status" data-dropdown-css-class="select2-info"
                    style="width: 100%;">
                    <option value="1" <?php if(isset($realty_post) && $realty_post->status == 1): ?> selected <?php endif; ?> >Tin chưa duyệt</option>
                    <option value="2" <?php if(isset($realty_post) && $realty_post->status == 2): ?> selected <?php endif; ?> >Đã thanh toán</option>
                    <option value="3" <?php if(isset($realty_post) && $realty_post->status == 3): ?> selected <?php endif; ?> >Tin đã duyệt</option>
                    <option value="4" <?php if(isset($realty_post) && $realty_post->status == 4): ?> selected <?php endif; ?> >Tin rác</option>
                </select>
            </div>

            <div class="form-group">
                <label class="col-form-label mr-2 d-block" name="is_featured" for="">Tin nổi bật</label>
                <input class=""
                name="is_featured"
                type="checkbox"
                <?php if(isset($realty_post->is_featured)): ?>
                    <?php if($realty_post->is_featured == 1 ): ?>
                        selected
                    <?php endif; ?>
                <?php endif; ?>
                data-bootstrap-switch
                data-off-color="danger"
                data-on-color="success">
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Lịch đăng tin</h3>
            <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                    <i class="fas fa-minus"></i>
                </button>
            </div>
        </div>
        <div class="card-body">
            <div class="form-group">
                <label>Loại tin đăng</label>
                <select class="form-control select2 select2-info" value="" name="rank" data-dropdown-css-class="select2-info"
                    style="width: 100%;">
                    <option value="1" <?php if(isset($realty_post) && $realty_post->rank == 1): ?> selected <?php endif; ?> >Tin thường</option>
                    <option value="2" <?php if(isset($realty_post) && $realty_post->rank == 2): ?> selected <?php endif; ?> >Tin Vip</option>
                    <option value="3" <?php if(isset($realty_post) && $realty_post->rank == 3): ?> selected <?php endif; ?> >Tin ưu đãi</option>
                    <option value="4" <?php if(isset($realty_post) && $realty_post->rank == 4): ?> selected <?php endif; ?> >Tin Vip đặc biệt</option>
                </select>
            </div>

            <div class="form-group">
                <label class="">Ngày bắt đầu</label>
                <input
                id="date-picker"
                <?php if(isset($realty_post)): ?>
                value="<?php echo e(Carbon\Carbon::parse( $realty_post->open_at)->format('d/m/Y') ?? ''); ?>"
                <?php endif; ?>
                class="date-picker form-control"
                type="text"
                name="open_at"
                >
                <?php $__errorArgs = ['open_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <label class="">Ngày kết thúc</label>
                <input
                id="date-picker"
                <?php if(isset($realty_post)): ?>
                value="<?php echo e(Carbon\Carbon::parse( $realty_post->close_at)->format('d/m/Y') ?? ''); ?>"
                <?php endif; ?>
                class="date-picker form-control"
                type="text"
                name="close_at"
                >
                <?php $__errorArgs = ['close_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    </div>
</div>

<?php $__env->startSection('css'); ?>
    ##parent-placeholder-2f84417a9e73cead4d5c99e05daff2a534b30132##
    <link rel="stylesheet" href="<?php echo e(asset('template/dropzone-5.7.0/dist/dropzone.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##
    <script src="<?php echo e(asset('template/dropzone-5.7.0/dist/dropzone.js')); ?>"></script>
    <script defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDWTx7bREpM5B6JKdbzOvMW-RRlhkukmVE&callback=initMap"> </script>
    <script>
        async function getPlace(url) {
            let data = await fetch(url).then(res => res.json());
            return data;
        }

        function getFullAddress(){
            $address = $('[name="street"]').val() + ',' + $('#commune option:selected').text() + ',' + $('#district option:selected').text() + ',' + $('#province option:selected').text();

            return $address;
        }

        function initMap() {
            // The location of Uluru

            <?php if(isset($realty)): ?>
            var current = {
                lat: <?php echo e($realty->google_map_lat ?? 21.027964); ?>,
                lng: <?php echo e($realty->google_map_lng ?? 105.8510132); ?>,
            };
            <?php else: ?>
            var current = {
                lat:  21.027964,
                lng: 105.8510132
            };
            <?php endif; ?>


            // The map, centered at Uluru
            var map = new google.maps.Map(
                document.getElementById('map'), { zoom: 17, center: current, optimized: true });
            // The marker, positioned at Uluru
            var marker = new google.maps.Marker({
                position: current,
                map: map,
                draggable: true,
            });
            map.addListener('mouseout', function () {
                $('[name="google_map_lat"]').val(marker.getPosition().lat());
                $('[name="google_map_lng"]').val(marker.getPosition().lng());
            });

            $('.address_input').on('blur', function(e){
                var address = getFullAddress();
                changeMarker(address);
            })

            function changeMarker(address){
                let link = `http://localhost:91/api/get-geo-by-mane?search_string=${address}`
                getPlace(link).then(data => {
                    geo = data.candidates[0].geometry.location;
                    marker.setPosition( new google.maps.LatLng( geo.lat, geo.lng ) );
                    map.panTo( new google.maps.LatLng( geo.lat, geo.lng ));
                    $('[name="google_map_lat"]').val(geo.lat);
                    $('[name="google_map_lng"]').val(geo.lng);
                });
            }
        }
        Dropzone.autoDiscover = false;
        $('#class_name').on('blur', function () {
        getSlug('online_class', $(this).val(), $('#slug'));
        });

        function getDistricts(province_code){
            url = '/get-district-of-province/' + province_code;
            return $.ajax({
                url: url,
                type: 'get',
            })
        }
        $('#province').on('change', function(){
            var province_code = $(this).val();
            var district_inputs = '<option value="">Quận/Huyện</option>';
            getDistricts(province_code)
            .done(function(data){
                data.forEach(element => {
                    district_inputs += `<option value="${element.code}">${element.name_with_type}</option>`;
                });
                $('#district').html(district_inputs);
            });
        })

        function getCommunes(district_code){
            url = '/get-commune-of-district/' + district_code;
            return $.ajax({
                url: url,
                type: 'get',
            })
        }

        $(document).on('change', "#district" , function(){
            var district_code = $(this).val();
            var commune_inputs = '<option value="">Phường/Xã</option>';
            getCommunes(district_code)
            .done(function(data){
                data.forEach(element => {
                    commune_inputs += `<option value="${element.code}">${element.name_with_type}</option>`;
                });
                $('#commune').html(commune_inputs);
            });
        })

            // get slug
        $('#title').on('blur', function () {
            console.log('jsdf');
            getSlug('realty_post', $(this).val(), $('#slug'));
        });

    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH /home/datnentayninh/domains/datnentayninh.org/public_html/resources/views/admin/pages/realty_post/form.blade.php ENDPATH**/ ?>