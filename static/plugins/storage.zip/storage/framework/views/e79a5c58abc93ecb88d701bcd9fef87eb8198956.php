<div class="block realty">
    <div class="realty-container shadow-6 flex-wrap rounded d-flex d-md-block">
        <div class="overflow-hidden col-5 px-0 col-md-12 order-2 bg-white">
            <a href="<?php echo e($item->link); ?>"class="d-block ml-2 ml-md-0 img-wraper height-md-180 height-120">
                <img src="<?php echo e($item->thumb); ?>" alt="" srcset="">
            </a>
            <?php if($item->rank == 4): ?>
                <div class="ribbon-wrapper ribbon">
                    <div class="ribbon bg-danger font-6 text-white">
                    Nổi bật
                    </div>
                </div>
            <?php endif; ?>
            <?php if($item->rank == 3): ?>
                <div class="ribbon-wrapper ribbon">
                    <div class="ribbon bg-info font-6 text-white">
                    Vip
                    </div>
                </div>
            <?php endif; ?>
        </div>
        <div class="order-1 col-12 bg-white px-2 pt-2 pb-2 pb-md-0">
            <a href="<?php echo e($item->link); ?>" class="d-block font-9 main-text w-100 hrm-truncate
                <?php if($item->rank == 4): ?>
                text-danger
                <?php endif; ?>
                <?php if($item->rank == 3): ?>
                text-info
                <?php endif; ?>
                " style="font-weight: 500; max-height: 2.56em; line-height: 1.3em"
                ><?php echo e($item->title); ?>

            </a>
        </div>
        <div class="realty-body col-7 col-md-12  bg-white order-3 px-2 pb-2">
            <div class="font-9 pt-2">
                <?php echo e($item->realty->district->name_with_type ?? ''); ?>, <?php echo e($item->realty->province->name ?? ''); ?>

            </div>

            <div class="d-flex justify-content-between text-dark py-1 font-9 ">
                <span class="font-weight-500">
                    <i class="fas fa-dollar-sign"></i>
                    <?php if($item->price_type !== 0): ?>
                    <?php echo e(\App\Helpers\CurrencyHelper::beautyPrice($item->price)); ?>

                    <?php endif; ?>
                    <?php echo e(config('constant.price_type.'. $item->price_type)['front_view']); ?>

                </span>
                <span class="font-weight-500"><i class="fas fa-expand"></i> <?php echo e($item->realty->area ?? ''); ?>m²</span>
            </div>
            <div class="font-9 d-flex justify-content-between">
                <span class="text-muted">
                    <?php echo e(\App\Helpers\TimeHelper::getDateDiffFromNow($item->created_at ?? '')['string']); ?> truớc
                </span>

                <div data-post-id="1" class="btnlike like-heart unchecked">
                    <i class="far fa-heart text-info font-12"></i>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/datnentayninh/domains/datnentayninh.org/public_html/resources/views/customer/components/realty_post/realty_block.blade.php ENDPATH**/ ?>