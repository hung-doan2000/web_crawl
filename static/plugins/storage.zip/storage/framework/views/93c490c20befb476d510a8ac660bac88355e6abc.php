<?php $__env->startSection('form'); ?>
<form action="<?php echo e(route('customer.realty_post.store')); ?>" method="POST" id="realty-post-form" class="p-3 bg-white info-credibility form-news">
    <?php echo csrf_field(); ?>
    <?php echo $__env->make('customer.pages.realty_post.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</form>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('customer.user_profile.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/datnentayninh/domains/datnentayninh.org/public_html/resources/views/customer/user_profile/create_post.blade.php ENDPATH**/ ?>