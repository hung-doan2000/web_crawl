<div class="modal modal-login fade" id="popup-login" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content px-4 pb">
      <div class="modal-body">
        <div class="logo-login text-center">
          <img src="<?php echo e(asset('images/logo.png')); ?>" alt="">
        </div>
        <div class="pt-2 mb-3 text-center">
            <strong class="text-blue-dark font-13">Đăng nhập vào tại khoản của bạn</strong>
        </div>
        <form action="/login" method="POST" id="form-login" class="form-login font-9">
          <?php echo csrf_field(); ?>
          <div class="form-group">
            <div class="bl-div div-phone">
                <label for="username">Số điện thoại / Email</label>
              <input type="text" name="username" class="form-control font-9" value="" placeholder="Email">
            </div>
          </div>
          <div class="form-group">
            <div class="bl-div div-password">
                <label for="username">Mật khẩu</label>
                <input data-type="password" type="password" name="password" value="" class="form-control font-9" placeholder="Mật khẩu">
                <span class="span-eyes"></span>
            </div>
            <div class="errors_input text-danger">
              <?php $__errorArgs = ['login_fail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="bl-remember font-9">
            <div class="d-flex justify-content-between align-items-center">
              <div class="checkbox bl-checkbox">
                <input id="remenber_pass_1" class="requestType" type="checkbox" name="remenber" value="1">
                <label for="remenber_pass_1">Ghi nhớ tài khoản</label>
              </div>
              <div class=""><a href="#" id="myforgot-password" data-toggle="modal" data-target="#forgot-password"><strong>Quên mật khẩu?</strong> </a></div>
            </div>

          </div>
          <div class="form-group mt-3">
            <button type="submit" class="btn login-btn w-100" id="login-normal">ĐĂNG NHẬP</button>
          </div>
          <div class="bl-creat-account font-9 text-center"><span>Chưa có tài khoản?</span> <a href="#" id="myregister" data-toggle="modal" data-target="#register" class="color-blue">Đăng ký ngay</a></div>
        </form>
      </div>
    </div>

  </div>
</div>


<?php $__env->startSection('script'); ?>
  ##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##
  <?php if($errors->has('login_fail')): ?>
    <script>
      $(document).ready(function(){
        $('#popup-login').modal('toggle')
      });
    </script>
  <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php /**PATH /home/datnentayninh/domains/datnentayninh.org/public_html/resources/views/customer/auth/login.blade.php ENDPATH**/ ?>