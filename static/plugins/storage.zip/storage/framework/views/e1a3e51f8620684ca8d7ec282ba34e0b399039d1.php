<?php
	$logos = explode(',', $theme_options['logo'] ?? '');
	$logo = '';
	foreach ($logos as $temp) {
		if ($temp != '') {
			$logo = $temp;
		}
	}
?>
<?php $__env->startSection('css'); ?>
    <style>
        .menu-open{
            margin: 0;
            padding: 0;
            top:0;
        }
    </style>
<?php $__env->stopSection(); ?>

<div class="navigation sticky-top bg-white">
    <div class="header-container p-md-3 border-bottom">
        <header class="" id="top" role="banner">
            <section class="menu-desktop d-none d-md-flex align-items-center">
                <div class="navbar-header">
                    <div class="" id="brand">
                        <a href="/"><img style="max-height: 75px" src="<?php echo e($logo); ?>" alt="brand"></a>
                    </div>
                </div>
                <nav class="d-flex align-items-center desktop-menu">
                    <?php $__currentLoopData = $main_menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="menu-item p-3 <?php if(isset($item->childs) && $item->childs != []): ?> has-child <?php endif; ?>"><a class="font-weight-bold main-text font-9" href="<?php echo e($item->href ?? '#'); ?>"> <?php echo e($item->title); ?></a>
                        <?php if(isset($item->childs)): ?>
                            <?php if($item->childs->isNotEmpty()): ?>
                                <ul class="child-navigation submenu-1 border px-3 bg-white rounded shadow-10">
                                    <?php $__currentLoopData = $item->childs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="py-2"><a class="main-text" href="<?php echo e($child->href); ?>"><?php echo e($child->title); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </nav>
                <div class="ml-auto d-block pr-3">
                    <a style="position: relative; width: auto; top:0; z-index:2"  href="#" class="pl-3 d-xl-none menu-open font-15 text-secondary" ><i class="far fa-bars"></i></a>
                </div>
                <div class="header-right ml-auto d-none d-xl-flex align-items-center">
                    <?php if(Auth::check()): ?>
                    <div class="login-logout">
                        <a class="text-dark font-9" href="/tai-khoan">
                            <img src="<?php echo e(auth()->user()->profile_image_path ?? '/images/empty-avatar.jpg'); ?>" style="width: 50px; height:50px" alt="">
                            <strong class="border-right px-2"><?php echo e(auth()->user()->name); ?></strong>
                        </a>
                        <a class="text-dark font-9" href="/logout"><span class="px-2">Đăng xuất</span></a>
                        <a href="/dang-tin" class="ml-2 font-9 hrm-btn-info p-2"><strong>Đăng tin</strong></a>
                    </div>
                    <?php else: ?>
                    <div class="login-logout">
                        <a href="#" class="text-dark px-2 font-9" data-toggle="modal" data-target="#register">Đăng ký</a>
                        <a href="#" class="text-dark font-9" data-toggle="modal" data-target="#popup-login"><span class="border-left px-2">Đăng nhập</span></a>

                        <span href="/dang-tin" class="ml-2 btn font-9 btn-outline-info" data-toggle="modal" data-target="#popup-login"><strong>Đăng tin</strong></span>
                    </div>
                    <?php endif; ?>
                </div>
            </section>
        </header>
    </div>
    <section class="header-mobile px-3 pt-2 pb-2 d-md-none" style="background: #024073">
        <div class="d-flex justify-content-between align-items-center">
            <div class="nav-search-btn-scroll  w-100" style="display: none">
                <a class="nav-search-open text-dark d-md-none rounded p-2 d-block bg-white" data-toggle="modal" data-target="#nav-search">
                    <i class="far fa-search font-10"></i> <span class="font-9" style="font-weight: 500">Tìm kiếm bất động sản</span>
                </a>
            </div>
            <a  href="/" class="logo-mobile"><img src="<?php echo e($logo); ?>" alt="brand"></a>
            <a style="position: relative; width: auto; top:0; z-index:2"  href="#" class="pl-3 menu-open font-15 text-white d-md-none" ><i class="far fa-bars"></i></a>
        </div>
        <div class="nav-search-btn">
            <a class="nav-search-open text-dark d-md-none rounded p-2  d-block bg-white w-100" data-toggle="modal" data-target="#nav-search">
                <i class="far fa-search font-10"></i> <span class="font-9" style="font-weight: 500">Tìm kiếm bất động sản</span>
            </a>
        </div>
</section>
</div>

<?php if(Agent::isMobile()): ?>
<?php echo $__env->make('customer.components.search.nav_search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php $__env->startSection('script'); ?>
##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##
    <script>
        $(window).on('scroll', function(){
            var top = $(window).scrollTop();
            if (top > 100) {
                $('.nav-search-btn').hide();
                $('.nav-search-btn-scroll').show();
                $('.logo-mobile').hide();
            }else if(top == 0){
                $('.nav-search-btn').show();
                $('.nav-search-btn-scroll').hide();
                $('.logo-mobile').show();
            }
        })
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH /home/datnentayninh/domains/datnentayninh.org/public_html/resources/views/customer/partials/header.blade.php ENDPATH**/ ?>