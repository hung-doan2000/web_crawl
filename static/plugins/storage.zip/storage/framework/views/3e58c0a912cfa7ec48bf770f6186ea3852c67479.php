<?php $__env->startSection('preset_seo'); ?>
    <?php
        $custom_keywords = implode(',', $title);
        $custom_title = implode(' ', $title) ?? '';
        $custom_description = implode(' ', $title) ?? '';
    ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?><?php echo e($seo->title ?? implode(' ', $title)); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('customer.components.search_top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-content hrm-bg-secondary">
	<div class="container">
        <div class="pt-3"><?php echo e(\App\Helpers\Breadcrumbs\RealtyBreadcrumbHelper::render()); ?> </div>
        <?php
            $links = \App\Helpers\Breadcrumbs\RealtyBreadcrumbHelper::createRealtyBreadcrumb(request()->filter);
        ?>
		<div class="row">
			<div class="col-md-9">
				<div class="entry-head-3 mt-2">
					<div class="ht mb-3">
                        <?php if(!empty($links)): ?>
                        <h1 class="font-15">Bất động sản <?php echo e($links[count($links) - 1]['name'] ?? ''); ?></h1>
                        <?php else: ?>
                        <h1 class="font-15">Tất cả bất động sản</h1>
                        <?php endif; ?>
						<div class="address font-10 text-secondary d-flex justify-content-between align-items-center">
                            <span class="hot">Hiện có  <?php echo e($realties->total()); ?> bất động sản</span>

                            <div class="group-header d-flex align-items-center">
                                <div class="item mr-auto">
                                    <select class="select2-hide-search sort border">
                                        <option val="">Sắp xếp</option>
                                        <option value="price">Giá từ thấp đến cao</option>
                                        <option value="-price">Giá từ cao xuống thấp</option>
                                        <option value="area">Diện tích từ nhỏ đến lớn</option>
                                        <option value="-area">Diện tích từ lớn đến nhỏ</option>
                                    </select>
                                </div>
                            </div>
                        </div>
					</div>
				</div>
				<div id="view-as-grid">
					<div class="row bds-hot-district mt-3">
                        <?php $__currentLoopData = $realties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $realty_post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 mb-3">
                            <?php echo $__env->make('customer.components.realty_post.realty_block', ['item' => $realty_post], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
				<?php echo e($realties->onEachSide(5)->links()); ?>

				
            </div>
            <div class="col-md-3 mt-4">

                <?php echo $__env->make('customer.pages.realty_post.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    ##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##
    <script>
        $(".realty-price").each(function(item){
            $(this).text( beautyPrice($(this).data('price')));
        })

        $('.realty-desc').each(function(){
            maxText($(this), 150);
        })

        $('.sort').on('change', function(){
            var regex = new RegExp("sort=[-a-z]+", 'g'); ;

            var href = window.location.href;
            if (href.search(regex) !== -1) {
                window.location = href.replace(regex, 'sort=' + $(this).val())
                return;
            } else {
                if (href.indexOf('?') == -1) {
                    window.location = href + '?sort=' + $(this).val();
                    return
                }else{
                    window.location = href + '&sort=' + $(this).val();
                    return
                }
            }
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/datnentayninh/domains/datnentayninh.org/public_html/resources/views/customer/pages/realty.blade.php ENDPATH**/ ?>