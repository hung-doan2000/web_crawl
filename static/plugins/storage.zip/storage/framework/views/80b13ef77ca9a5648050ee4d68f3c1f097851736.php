<?php $__env->startSection('title'); ?>
<?php echo e($project->name); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('plugins/lightgallery/dist/css/lightgallery.min.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-details project-detail pt-5 hrm-bg-secondary">
	<div class="container">
		<div class="row">
			<div class="col-md-8 bg-white py-3 mb-5">
                <div class="feature">
                    <div class="thumnail">
                        <div id="big" class="lightgallery thumnail-big owl-carousel owl-theme">
                            <?php $__currentLoopData = $project->overview_image_array ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div data-src="<?php echo e($img); ?>" class="item embed-responsive embed-responsive-16by9">
                                <img class="embed-responsive-item rounded" src="<?php echo e($img); ?>" alt="">
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div id="thumbs" class="thumnail-thumbs owl-carousel owl-theme mt-2">
                            <?php $__currentLoopData = $project->overview_image_array ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item embed-responsive embed-responsive-16by9">
                                <img class="embed-responsive-item rounded" src="<?php echo e($img); ?>" alt="">
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>

				<div class="content-detail mt-4">
                    <div class=" pl-0">
                        <div class="breadcrumbs">
                            <a class="secondary-text" href="/">Trang chủ</a>
                            / <a class="secondary-text" href="/du-an-bat-dong-san">Dự án</a>
                            / <a class="main-text" href="#"><?php echo e($project->name); ?></a>
                        </div>
                    </div>
                    <h1 class="text-dark font-15 entry-title mb-3"><?php echo e($project->name ?? 'Đang cập nhật'); ?></h1>
                    <div class=" pb-4 mb-4 font-10">
                        <div class="py-2"><?php echo e($project->full_address); ?></div>
                        <span class="mr-3">
                            Trạng thái: <strong class="main-blue"><?php echo e(config('constant.project_status.'. $project->status)['name'] ?? 'Đang cập nhật'); ?></strong>
                        </span>
                        <span class="mr-3">
                            Chủ đầu tư: <strong><?php echo e($project->investor); ?></strong>
                        </span>
                        <span class="">
                            Khoảng giá:
                            <strong>
                                <?php if($project->min_price && $project->max_price): ?>
                                <?php echo e(\App\Helpers\CurrencyHelper::beautyPrice($project->min_price)); ?> - <?php echo e(\App\Helpers\CurrencyHelper::beautyPrice($project->max_price)); ?>

                                <?php else: ?>
                                    Đang cập nhật
                                <?php endif; ?>
                            </strong>
                        </span>
                    </div>
                    <div class="py-4 d-md-flex justify-content-between align-items-center border-bottom border-top">
                        <div class="d-flex">
                            <div class="pr-3">
                                <p class="mb-1" >Mức giá</p>
                                <strong class="font-12">
                                    <?php if($project->min_price && $project->max_price): ?>
                                    <?php echo e(\App\Helpers\CurrencyHelper::beautyPrice($project->min_price)); ?> - <?php echo e(\App\Helpers\CurrencyHelper::beautyPrice($project->max_price)); ?>

                                    <?php else: ?>
                                        Đang cập nhật
                                    <?php endif; ?>
                                </strong>
                            </div>
                            <div class="px-3">
                                <p class="mb-1" >Diện tích xây dựng</p>
                                <strong class="font-12"> <?php echo e($project->site_area . ' m2' ?? 'Đang cập nhật'); ?></strong>
                            </div>
                            <div class="pl-3">
                                <p class="mb-1" >Bàn giao</p>
                                <strong class="font-12">
                                    <?php echo e(\Carbon\Carbon::parse($project->launch_time)->format('d/m/Y') ?? 'Đang cập nhật'); ?>

                                </strong>
                            </div>
                        </div>
                        <div>
                            <div class="group-btn share-group">
                                <?php echo $__env->make('customer.components.share_button', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <a class="btn btn-map" data-toggle="modal" data-target="#show-map"><i class="far fa-map-marker font-12"></i> Vị trí</a>
                            </div>
                        </div>
                    </div>
				</div>
				<div id="menu-project" class="menucontent menu-project my-3">
					<a class="font-14 secondary-text pr-3 py-2" href="#info">Thông tin</a>
					<a class="font-14 secondary-text px-3 py-2 " href="#gallery">Hình ảnh</a>
					<a class="font-14 secondary-text px-3 py-2 " href="#rental">BĐS THUÊ (<?php echo e($project->rent_realty->count()); ?>)</a>
					<a class="font-14 secondary-text px-3 py-2 " href="#vendor">BĐS BÁN (<?php echo e($project->sell_realty->count()); ?>)</a>
				</div>
				<div class="panel-group boxwidget" id="accordion">
					<div class="panel pt-2">
						<div class="panel-heading">
							<h4 class="panel-title">
								<a data-toggle="collapse" data-parent="#accordion" href="#info">Tổng quan <span class="triangle"><i class="fa fa-angle-down" aria-hidden="true"></i></span></a>
							</h4>
						</div>
						<div id="info" class="panel-collapse">
							<div class="panel-body">
                                <?php echo $project->description; ?>

							</div>
						</div>
					</div>
					<div class="panel pt-2">
						<div class="panel-heading">
							<h4 class="panel-title">
								<a data-toggle="collapse" data-parent="#accordion" href="#location">Vị trí hạ tầng <span class="triangle"><i class="fa fa-angle-down" aria-hidden="true"></i></span></a>
							</h4>
						</div>
						<div id="location" class="panel-collapse">
							<div class="panel-body">
                                <div>
                                    <?php echo $project->location_description; ?>

                                </div>
							</div>
						</div>
                    </div>
                    <div id="gallery" class="pt-2 panel picture page-section">
						<div class="panel-heading">
							<h4 class="panel-title">
								<a data-toggle="collapse" data-parent="#accordion" href="#picture">Sơ đồ dự án <span class="triangle"><i class="fa fa-angle-down" aria-hidden="true"></i></span></a>
							</h4>
						</div>
						<div id="picture" class="panel-collapse">
							<div class="panel-body">
								<ul class="nav nav-tabs menucontent">
                                    <li class="py-2 pr-3"><a data-toggle="tab" href="#ground_total" class="active">Sơ đồ tổng thế</a></li>
                                    <?php $__currentLoopData = $project->grounds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="py-2 px-3"><a data-toggle="tab" href="#ground<?php echo e($item->id); ?>"><?php echo e($item->name); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</ul>
								<div class="tab-content mt-3">
                                    <div id="ground_total" class="active tab-pane over-all-diagram">
										<div class="row">
                                            <div class="col-md-3">
                                                <div href="<?php echo e($project->over_all_diagram_array[0] ?? ''); ?>" class="img-wraper item">
                                                    <img src="<?php echo e($project->over_all_diagram_array[0] ?? ''); ?>" alt="" />
                                                </div>
                                            </div>
										</div>
									</div>
                                    <?php $__currentLoopData = $project->grounds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div id="ground<?php echo e($item->id); ?>" class="tab-pane fade">
										<div class="row">
                                            <?php $__currentLoopData = $item->image_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-md-3">
                                                    <div class="item">
                                                        <div href="<?php echo e($item); ?>" class="img-wraper item" >
                                                            <img src="<?php echo e($item); ?>" alt="" />
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</div>
									</div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</div>
							</div>
						</div>
                    </div>
					<div class="panel pt-2">
						<div class="panel-heading">
							<h4 class="panel-title">
								<a data-toggle="collapse" data-parent="#accordion" href="#investor">Chủ đầu tư <span class="triangle"><i class="fa fa-angle-down" aria-hidden="true"></i></span></a>
							</h4>
						</div>
						<div id="investor" class="panel-collapse">
							<div class="panel-body">
                                <?php echo e($project->investor); ?>

                            </div>
						</div>
					</div>
				</div>
				<div id="rental" class="rental page-section">
					<div class="entry-head text-center pb-2 d-flex  justify-content-between align-items-center">
                        <h2 class="font-14 home-title">Bất động sản nổi cho thuê</h2>
                        <a href="/<?php echo e(config('constant.realty_post_type.2.slug')); ?>-<?php echo e($project->slug); ?>" class="text-dark">Xem tất cả <i class="fas fa-long-arrow-alt-right"></i></a>
                    </div>
					<div class="list-project">
						<div class="list-rental owl-carousel">
                            <?php $__currentLoopData = $project->rent_realty; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="item p-2">
                                    <?php echo $__env->make('customer.components.realty_post.realty_block', ['item' => $item], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>
				</div>
				<div id="vendor" class="vendor page-section pt-3">
					<div class="entry-head text-center pb-2 d-flex  justify-content-between align-items-center">
                        <h2 class="font-14 home-title">Bất động sản bán</h2>
                        <a href="/<?php echo e(config('constant.realty_post_type.1.slug')); ?>-<?php echo e($project->slug); ?>" class="text-dark">Xem tất cả <i class="fas fa-long-arrow-alt-right"></i></a>
                    </div>
					<div class="list-project">
						<div class="list-vendor owl-carousel">
                            <?php $__currentLoopData = $project->sell_realty; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="item p-2">
                                    <?php echo $__env->make('customer.components.realty_post.realty_block', ['item' => $item], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>
				</div>
            </div>
            <div class="col-md-4">
                <?php echo $__env->make('customer.components.sidebars.realty_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    ##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##
    <script src="<?php echo e(asset('plugins/lightgallery/dist/js/lightgallery.min.js')); ?>"></script>
    <script>

        lightGallery(document.querySelector('.lightgallery'), {
            selector: '.item'
        });

        lightGallery(document.querySelector('.over-all-diagram'), {
            selector: '.item'
        });

        <?php $__currentLoopData = $project->grounds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        lightGallery(document.getElementById("ground<?php echo e($item->id); ?>"), {
            selector: '.item'
        });
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        $('.list-rental, .list-vendor').owlCarousel({
            items: 3,
            loop: true,
            margin: 0,
            dots: false,
            nav: false,
            autoplay: false,
            autoplayTimeout: 3000,
            autoplaySpeed: 1200,
            smartSpeed: 1200,
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/datnentayninh/domains/datnentayninh.org/public_html/resources/views/customer/pages/project/show.blade.php ENDPATH**/ ?>