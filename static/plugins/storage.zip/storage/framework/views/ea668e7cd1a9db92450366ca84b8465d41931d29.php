<div class="input-group file-btn-wraper">
    <input type="hidden" name="<?php echo e($input_name); ?>" value="<?php echo e($current_input); ?>" class="form-field stand-alone-input">
    <div class="image-holder">
        <?php
            $current_input = explode(",",$current_input);
        ?>

        <?php $__currentLoopData = $current_input; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $thumb_url = null;
                if ($item !== '') {
                    $last = strrpos($item, '/');
                    $thumb_url = substr_replace($item, '/thumbs', $last, 0);
                }
            ?>
            <?php if($thumb_url): ?>
                <div class="d-inline-block image-wraper text-center p-2 mr-1 mb--2" style="border: 1px dashed gray;">
                    <div class="img" style="object-fit: contain; height:8rem; width:8rem">
                        <img style="width: 100%" src="<?php echo e($thumb_url); ?>">
                    </div>
                    <button style="cursor-pointer"
                    type="button"
                    class="stand-alone-image-delete p-1 d-block btn btn-link text-red mx-auto"
                    data-image="<?php echo e($item); ?>">Xóa hình ảnh</button>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <span class="input-group-btn">
        <a id="<?php echo e($id); ?>"
        data-input="thumbnail"
        data-preview="holder"
        class="d-block"
        style=" border: 1px dashed gray;">
            <img style="height:8rem; width:8rem; cursor: pointer;" src="<?php echo e(asset('/images/placeholder.png')); ?>">
            <button type="button" class="p-1 d-block btn btn-link text-red mx-auto">Thêm mới</button>
        </a>
    </span>
</div>

<?php $__env->startSection('script'); ?>
##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##
<script>
    lfm("<?php echo e($id); ?>", 'image', { prefix: '/admin/laravel-filemanager' });
</script>
<?php $__env->stopSection(); ?>
<?php /**PATH /home/datnentayninh/domains/datnentayninh.org/public_html/resources/views/admin/components/button_file_manager.blade.php ENDPATH**/ ?>