<section class="random-realty py-3 py-lg-5 section hrm-bg-secondary">
	<div class="container">
        <div class="d-md-flex">
            <h3 class="font-18 color-dark home-title">Bất động sản dành cho bạn</h3>
            <div class="ml-auto d-flex align-items-center ">
                <a href="/ban" class="px-md-2 border-md-right secondary-text">Tin nhà đất bán mới nhất</a>
                <a href="/cho-thue" class="px-md-2 secondary-text">Tin nhà đất cho thuê mới nhất</a>
            </div>
        </div>

        <div class="row pt-3">
            <?php $__currentLoopData = $random_realties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item col-md-3 my-2 wow fadeIn"
            data-wow-offset="1"
            data-wow-delay="<?php echo e(0.1 * $index); ?>s"
            >
                <?php echo $__env->make('customer.components.realty_post.realty_block', ['item' => $item], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php /**PATH /home/datnentayninh/domains/datnentayninh.org/public_html/resources/views/customer/contents/hot_realty.blade.php ENDPATH**/ ?>