<?php $__env->startSection('title'); ?>
Tin tức bất động sản
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
##parent-placeholder-2f84417a9e73cead4d5c99e05daff2a534b30132##
<style>

    .category-post-title{
        line-height: 22px;
    }
    .category-post-title:before{
        content: '';
        width: 6px;
        height: 6px;
        border-radius: 50%;
        background: #eb5155;
        display: inline-block;
        float: left;
        margin-top: 7px;
        margin-right: 8px;
        flex: 0 0 6px;
    }

    .province{
        line-height: 30px;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="blog-wrapper blog-post hrm-bg-secondary">
	<div class="container pt-4">
        <div class="breadcrumbs">
            <a class="secondary-text" href="/">Trang chủ</a>
            / <a class="secondary-text" href="/tin-tuc">Tin tức</a>
            / <a class="main-text" href="#">Tin tức <?php echo e($tag->name); ?></a>
        </div>
		<div class="entry-head pt-2">
			<h1 class="font-20 home-title">Tin tức <?php echo e($tag->name); ?></h1>
        </div>

		<div class="row mb-5">
			<div class="col-md-8">
				<div class="featured-blog p-md-4 rounded-1 bg-white">
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="category-blog p-4 rounded-1 bg-white">
                        <div class="top-post row">
                            <div class="col-sm-5">
                                <a class="d-block rounded-1 img-wraper" href="<?php echo e(route('customer.post.show',['cat_slug' => $post->categories->first()->slug ?? 'danh-muc', 'post_slug' => $post->slug] )); ?>">
                                    <img style="max-height: 200px" class="rounded" src="<?php echo e($post->thumb ?? ''); ?>" alt="<?php echo e($post->name ?? ''); ?>">
                                </a>
                            </div>
                            <div class="post-link col-sm-7 pl-sm-0">
                                <a style="font-weight: 500" class="font-13 text-dark post-title" href="<?php echo e(route('customer.post.show',['cat_slug' => $post->categories->first()->slug ?? 'danh-muc', 'post_slug' => $post->slug] )); ?>"><?php echo e($post->name); ?></a>
                                <div class="mt-2">
                                    <span class="font-10 post-description ">
                                        <?php echo e($post->short_description); ?>

                                    </span>
                                </div>
                                <div class="cl-main-text mt-3 text-muted">
                                    <?php echo e(App\Helpers\TimeHelper::getDateDiffFromNow($post->created_at)['string'] ?? ''); ?> trước
                                </div>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <?php echo e($posts->links()); ?>

			</div>
			<?php echo $__env->make('customer.pages.posts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    ##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##
    <script>
        $('.post-title').each(function(){
            maxText($(this), 60);
        })

        $('.post-description').each(function(){
            maxText($(this), 180);
        })
        maxText($('.blog_excerpt'), 90);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/datnentayninh/domains/datnentayninh.org/public_html/resources/views/customer/pages/posts/list_by_tag.blade.php ENDPATH**/ ?>