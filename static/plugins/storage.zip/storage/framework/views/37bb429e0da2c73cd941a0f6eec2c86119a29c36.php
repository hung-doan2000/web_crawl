<?php $__env->startSection('title'); ?>
    Trang chủ
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

<?php echo $__env->make('admin.partials.content_header', ['title' => 'Quản lý menu'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('admin.pages.menu.menu_editor', [
    'category' => $category,
    'menu_list' => $menu_list,
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.main_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/datnentayninh/domains/datnentayninh.org/public_html/resources/views/admin/pages/menu/edit.blade.php ENDPATH**/ ?>