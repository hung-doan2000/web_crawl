<?php $__env->startSection('title'); ?>
Tin tức bất động sản
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
##parent-placeholder-2f84417a9e73cead4d5c99e05daff2a534b30132##
<style>

    .category-post-title{
        line-height: 22px;
    }
    .category-post-title:before{
        content: '';
        width: 6px;
        height: 6px;
        border-radius: 50%;
        background: #eb5155;
        display: inline-block;
        float: left;
        margin-top: 7px;
        margin-right: 8px;
        flex: 0 0 6px;
    }

    .province{
        line-height: 30px;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="blog-wrapper blog-post hrm-bg-secondary">
	<div class="container pt-4">
        <div class="breadcrumbs">
            <a class="secondary-text" href="/">Trang chủ</a>
            / <a class="main-text" href="#">Tin tức</a>
        </div>
		<div class="entry-head pt-2">
			<h1 class="font-20 home-title">Tin tức bất động sản</h1>
        </div>
        <?php
        $top_post = $featured_posts->first();
        ?>
		<div class="row">
			<div class="col-md-8">
				<div class="featured-blog p-4 rounded-1 bg-white">
                    <div class="top-post row">
                        <div class="col-sm-5">
                            <a class="rounded-1 d-block img-wraper" href="<?php echo e(route('customer.post.show',['cat_slug' => $top_post->categories->first()->slug ?? 'danh-muc', 'post_slug' => $top_post->slug] )); ?>"><img  style="max-height: 200px" src="<?php echo e($top_post->thumb ?? ''); ?>" alt="<?php echo e($top_post->name ?? ''); ?>">
                            </a>
                        </div>
                        <div class="post-link col-sm-7 pl-sm-0">
                            <a style="font-weight: 500" class="font-13 main-text" href="<?php echo e(route('customer.post.show',['cat_slug' => $top_post->categories->first()->slug ?? 'danh-muc', 'post_slug' => $top_post->slug] )); ?>"><?php echo e($top_post->name); ?></a>
                            <div class="mt-2">
                                <span class="font-10 post-description">
                                    <?php echo e($top_post->short_description); ?>

                                </span>
                            </div>
                            <div class="cl-main-text mt-3">
                                <?php echo e(App\Helpers\TimeHelper::getDateDiffFromNow($top_post->created_at)['string'] ?? ''); ?> trước
                            </div>
                            <div>
                                <?php $__currentLoopData = $top_post->tags->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(route('customer.post_tag.get_all', $tag->slug)); ?>" class="d-inline-block py-1 px-2 my-2  mr-2 hrm-btn-info-solid">
                                    <strong class="font-9">#<?php echo e($tag->name); ?></strong>
                                </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                    <div class="featured-post-slider owl-carousel mt-4">
                        <?php $__currentLoopData = $featured_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item rounded-1">
                                <a class="main-text" href="<?php echo e(route('customer.post.show',['cat_slug' => $item->categories->first()->slug ?? 'danh-muc', 'post_slug' => $item->slug] )); ?>">
                                    <div>
                                        <img style="height: 140px" src="<?php echo e($item->thumb); ?>" alt="">
                                    </div>
                                    <div class="post-title main-text pt-3">
                                    <?php echo e(Str::limit($item->name, 40, '')); ?>

                                    </div>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <?php $__currentLoopData = $post_categories->take(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $top_post = $category->posts->first();
                        $posts = $category->posts;
                    ?>
                    <?php if($posts->isNotEmpty()): ?>
                        <div class="category-posts mt-5">
                            <div class="category-header d-flex align-items-center justify-content-between mb-1">
                                <h3 class="p-0 bold home-title"><strong  class="uppercase"><?php echo e($category->name); ?></strong></h3>
                                <a class="secondary-text" href="<?php echo e(route('customer.post.show_by_category', $category->slug)); ?>"><span>Xem thêm</span>&nbsp; <i class="fa fa-chevron-right secondary-text font-9" aria-hidden="true"></i></a>
                            </div>
                            <div class="category-body">
                                <div class="category-blog p-4 rounded-1 bg-white">
                                    <div class="top-post row">
                                        <div class="col-sm-5">
                                            <a class="d-block rounded-1 img-wraper" href="<?php echo e(route('customer.post.show',['cat_slug' => $top_post->categories->first()->slug ?? 'danh-muc', 'post_slug' => $top_post->slug] )); ?>">
                                                <img style="max-height: 200px" src="<?php echo e($top_post->thumb ?? ''); ?>" alt="<?php echo e($top_post->name ?? ''); ?>">
                                            </a>
                                        </div>
                                        <div class="post-link col-sm-7 pl-sm-0">
                                            <a style="font-weight: 500" class="font-13 main-text" href="<?php echo e(route('customer.post.show',['cat_slug' => $top_post->categories->first()->slug ?? 'danh-muc', 'post_slug' => $top_post->slug] )); ?>"><?php echo e($top_post->name); ?></a>
                                            <div class="mt-2">
                                                <span class="font-10 post-description ">
                                                    <?php echo e($top_post->short_description); ?>

                                                </span>
                                            </div>
                                            <div class="cl-main-text mt-3 text-muted">
                                                <?php echo e(App\Helpers\TimeHelper::getDateDiffFromNow($top_post->created_at)['string'] ?? ''); ?> trước
                                            </div>
                                            <div>
                                                <?php $__currentLoopData = $top_post->tags->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <a href="<?php echo e(route('customer.post_tag.get_all', $tag->slug)); ?>" class="d-inline-block py-1 px-2 my-2 mr-2 hrm-btn-info-solid">
                                                    <strong class="font-9">#<?php echo e($tag->name); ?></strong>
                                                </a>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row mt-4">
                                        <?php $__currentLoopData = $posts->take(6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-sm-6  pb-3">
                                            <a class="main-text d-flex post-title category-post-title cl-main-text" href="<?php echo e(route('customer.post.show',['cat_slug' => $item->categories->first()->slug ?? 'danh-muc', 'post_slug' => $item->slug] )); ?>">
                                                <?php echo e($item->name); ?>

                                            </a>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
			<?php echo $__env->make('customer.pages.posts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    ##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##
    <script>
        $('.post-title').each(function(){
            maxText($(this), 100);
        })

        $('.post-description').each(function(){
            maxText($(this), 140);
        })
        maxText($('.blog_excerpt'), 90);

        $('.featured-post-slider').owlCarousel({
            loop:true,
            margin: 20,
            dots:false,
            nav:false,
            autoplay: true,
            autoplayTimeout:3000,
            autoplaySpeed:1200,
            smartSpeed:1200,
            responsive:{
                0:{
                    items:2,
                },
                600:{
                    items:3
                },
                1000:{

                    items:3.5
                }
            }
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/datnentayninh/domains/datnentayninh.org/public_html/resources/views/customer/pages/posts/index.blade.php ENDPATH**/ ?>