<?php
    $banners = explode(',', $theme_options['Banner'] ?? '');
    $banner_mobile = explode(',', $theme_options['Banner_mobile'] ?? '');

?>

<?php $__env->startSection('css'); ?>
    ##parent-placeholder-2f84417a9e73cead4d5c99e05daff2a534b30132##
    <style>
        .hidden-field{
            display:none;
        }
    </style>
<?php $__env->stopSection(); ?>
<section class="banner-home position-relative">
    <?php if(Agent::isMobile()): ?>
    <div class="banner-home-slider owl-carousel" style="z-index: 1">
            <?php $__currentLoopData = $banner_mobile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item): ?>
                    <div class="item img-responsive">
                        <img src="<?php echo e($item); ?>" alt=""  srcset="">
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php else: ?>
        <div class="banner-home-slider owl-carousel position-absolute h-100" style="z-index: -1">
            <?php $__currentLoopData = $banner_mobile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item): ?>
                    <div class="item w-100 banner-item">
                        <img src="<?php echo e($item); ?>" alt="" style="height: 100%; object-fit:cover" srcset="">
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

	<div class="container mx-auto clearfix pt-md-5 ">

		<div class="divtext text-center  d-none d-md-block">
			<h2><strong> BẤT ĐỘNG SẢN DỄ DÀNG</strong></h2>
			<p>Tìm kiếm bất động sản chỉ với một cú click chuột</p>
		</div>
		<div class="section-filter-home d-none d-md-block">
            <form action="" id="form-search">
                <div class="search-type d-flex">
                    <div class="search-type-item mr-1">
                        <input type="radio"  class="d-none" name="loai-tin-dang" value="1" id="realty-sell">
                        <label class="py-2 px-4 font-9 m-0 rounded-top" for="realty-sell"><strong>NHÀ ĐẤT BÁN</strong></label>
                    </div>
                    <div class="search-type-item">
                        <input class="d-none" type="radio" name="loai-tin-dang" checked value="2" id="realty-rent">
                        <label class="py-2 px-4 m-0 font-9 rounded-top" for="realty-rent"><strong>NHÀ ĐẤT CHO THUÊ</strong></label>
                    </div>
                </div>

                <div class="search-field p-2 ">
                    <div class="pt-2">
                        <div class="search-field-header bg-white d-md-flex align-items-center mx-2">
                            <div class="d-md-flex  align-items-center" style="flex: 0 0 calc(20%)">
                                
                                <select class="realty-type form-control border-0 select2 border-0" name="loai-bds">
                                    <option data-realty-post-type="1" value="">Loại nhà đất</option>
                                    <option data-realty-post-type="2" value="">Loại nhà đất</option>
                                    <?php $__currentLoopData = config('constant.realty_post_type'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type =>  $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $item['realty_type_list']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $realty_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option data-slug="<?php echo e(config('constant.realty_type.'.$realty_type)['slug']); ?>" data-realty-post-type="<?php echo e($type); ?>" value="<?php echo e($realty_type); ?>"><?php echo e(config('constant.realty_type.'.$realty_type)['name']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="address-input">
                                <input type="text" class="form-control rounded-0" name="dia-chi" placeholder="Nhập địa chỉ" >
                            </div>
                            <button style="width:" id="apply-search" type="button" style="flex: 0 0 calc(20%)" class="d-none d-md-block  btn btn-info rounded-0">Tìm kiếm</button>
                        </div>
                    </div>

                    <div class="search-criteria d-flex mt-2">
                        <div class="form-group mb-2 search-input pl-2 pr-1">
                            <select class="form-control select2 select2-info" id="province" name="tinh" data-dropdown-css-class="select2-info" style="width: 100%;">
                                <option value="">Tỉnh / Thành phố</option>
                                <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option data-slug="<?php echo e($province->slug); ?>" value="<?php echo e($province->code); ?>"><?php echo e($province->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group mb-2 search-input px-1">
                            <select class="form-control select2 select2-info realty-price"  name="gia" data-dropdown-css-class="select2-info" style="width: 100%;">
                                <?php
                                    function beautyPrice($price){
                                        if($price >= 1000){
                                            return $price / 1000 . ' tỉ';
                                        }elseif($price > 0){
                                            return $price . ' triệu';
                                        }else{
                                            return $price;
                                        }
                                    }
                                ?>

                                <?php $__currentLoopData = config('constant.realty_post_type'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type_id => $realty_post_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="">Giá</option>
                                    <?php $__currentLoopData = $list = $realty_post_type['price_range']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $range): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($index < count($list) - 1 ): ?>
                                            <option data-realty-post-type="<?php echo e($type_id); ?>"  name="gia" value="<?php echo e($list[$index] *1000000); ?>,<?php echo e($list[$index + 1] * 1000000); ?>"><?php echo e(beautyPrice($list[$index])); ?> - <?php echo e(beautyPrice($list[$index + 1])); ?></option>
                                        <?php else: ?>
                                            <option data-realty-post-type="<?php echo e($type_id); ?>" name="gia" value="<?php echo e($list[$index] *1000000); ?>,10000000000000">Trên <?php echo e(beautyPrice($list[$index])); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group mb-2 search-input px-1">
                            <select class="form-control select2 select2-info" value="" name="dien-tich" data-dropdown-css-class="select2-info" style="width: 100%;">
                                <option value="">Diện tích</option>
                                <?php $__currentLoopData = $list =  config('constant.realty_area_range'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <?php if($index < count($list) - 1 ): ?>
                                    <option value="<?php echo e($item); ?>,<?php echo e($list[$index + 1]); ?>"><?php echo e($item); ?> m2 - <?php echo e($list[$index + 1]); ?> m2</option>
                                    <?php else: ?>
                                    <option value="<?php echo e($item); ?>,10000">Trên <?php echo e($item); ?> m2</option>
                                    <?php endif; ?>
                                    </span></label>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group mb-2 search-input px-1">
                            <select class="form-control select2 select2-info" value="" name="huong" data-dropdown-css-class="select2-info" style="width: 100%;">
                                <option value="" selected="">Hướng</option>
                                <?php $__currentLoopData = config('constant.direction'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($index); ?>" ><?php echo e($item['name']); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="hidden-field form-group mb-2 search-input px-1">

                        </div>
                        <div class="hidden-field form-group mb-2 search-input pl-2 pr-1">
                            <select class="form-control select2 select2-info" value="" id="district" name="huyen" data-dropdown-css-class="select2-info" style="width: 100%;">
                                <option value="" selected="">Quận / Huyện</option>

                            </select>
                        </div>
                        <div class="hidden-field form-group mb-2 search-input px-1">
                            <select class="form-control select2 select2-info" value="" id="commune" name="xa" data-dropdown-css-class="select2-info" style="width: 100%;">
                                <option value="" selected="">Phường / xã</option>
                            </select>
                        </div>
                        <div class="hidden-field form-group mb-2 search-input px-1">
                            <select class="form-control select2 select2-info" id="" value="" name="du-an" data-dropdown-css-class="select2-info" style="width: 100%;">
                                <option value="" selected="">Dự án</option>
                            </select>
                        </div>
                        <div class="hidden-field px-1 form-group mb-2 search-input">

                        </div>
                        <div class="px-2  mb-2 search-input d-flex align-items-center" >
                            <div class="bg-white closed btn-expand-search w-100 btn rounded-0 text-left">
                                <i class="fas fa-expand-arrows-alt"></i>
                                Thêm
                            </div>
                        </div>
                        <button id="apply-search" type="button" class=" d-block d-md-none btn btn-info px-5 mx-auto rounded">Tìm kiếm</button>
                    </div>
                </div>

            </form>
		</div>
	</div>
</section>

<?php $__env->startSection('script'); ?>
	##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##
	<script>
        $('.btn-expand-search').on('click', function(){
            $('.hidden-field').toggle();
            if ($(this).hasClass('closed')) {
                console.log('hello');
                $(this).removeClass('closed');
                $(this).addClass('opened');
                $(this).html(`
                    <i class="fas fa-compress-arrows-alt"></i>Ẩn
                `);
            }

            if ($(this).hasClass('opened')) {
                $(this).removeClass('opened');
                $(this).addClass('closed');
                $(this).html(`
                    <i class="fas fa-expand-arrows-alt"></i>Thêm
                `);
            }

        })

        $("[name=loai-tin-dang]").on('change', function(){
            $postType = $(this).val();
            $(`.realty-type option`).prop('disabled', true);
            $(`.realty-type option[data-realty-post-type=${$postType}]`).prop('disabled', false);

            $(`.realty-price option`).prop('disabled', true);
            $(`.realty-price option[data-realty-post-type=${$postType}]`).prop('disabled', false);
        })


        function getDistricts(province_code) {
            url = '/get-district-of-province/' + province_code;
            return $.ajax({
                url: url,
                type: 'get',
            })
        }

        $('#province').on('change', function () {
            var province_code = $(this).val();
            var district_inputs = `<option value="" selected>Quận / huyện</option>`;
            getDistricts(province_code)
                .done(function (data) {
                    data.forEach(element => {
                        district_inputs += `<option data-slug="${element.slug}" value="${element.code}" >${element.name_with_type}</option>`
                    });
                    $('#district').html(district_inputs);
                });
        })

        function getCommunes(district_code) {
            url = '/get-commune-of-district/' + district_code;
            return $.ajax({
                url: url,
                type: 'get',
            })
        }

        $(document).on('change', "[name='huyen']", function () {
            var district_code = $(this).val();
            var commune_inputs = `<option value="" selected>Phường / xã</option>`;
            getCommunes(district_code)
                .done(function (data) {
                    data.forEach(element => {
                        commune_inputs += `<option data-slug="${element.slug}" value="${element.code}" >${element.name_with_type}</option>`
                    });
                    $('#commune').html(commune_inputs);
                });
        })


        function getQuery() {
            var data = $('#form-search').serializeArray();
            var result = {};
            data.forEach(function (item) {
                if (result[item.name]) {
                    result[item.name] += ',' + item.value;
                } else {
                    result[item.name] = item.value;
                }
            });

            var query = '/tim-kiem?';
            var queryElem = [];
            if (result['loai-tin-dang']) {
                queryElem.push( result['loai-tin-dang'] == 2 ? 'cho-thue' : 'ban' )
            }

            if (result['loai-bds']) {
                var realtyTypeSlug = $('.realty-type option:selected').data('slug');
                queryElem.push(realtyTypeSlug);
            }

            if (result['xa']){
                var realtyTypeSlug = $('#commune option:selected').data('slug');
                queryElem.push(realtyTypeSlug);
            }else if(result['huyen']){
                var realtyTypeSlug = $('#district option:selected').data('slug');
                queryElem.push(realtyTypeSlug)
            }else if(result['tinh']){
                var realtyTypeSlug = $('#province option:selected').data('slug');
                queryElem.push(realtyTypeSlug)
            }
            var slug = '/' + queryElem.join('-') + '?';
            var query = '';
            var validParam = ['dien-tich', 'du-an', 'huong', 'gia', 'dia-chi']
            Object.entries(result).forEach(function (item, index) {
                if (validParam.includes(item[0])) {
                    if (query === '' && item[1] != '') {
                        query += item[0] + '=' + item[1];
                        return
                    };

                    if (query !== '' && item[1] != '') {
                        query += '&' + item[0] + '=' + item[1];
                        return
                    }
                }
            });
            window.location = slug + query ;
        }
        $(document).on('click', '#apply-search', function () {
            getQuery();
        })

        $('.ms-search').on('click', function(e){
            e.stopPropagation();

        })

        $('.search-type label').on('click', function(){
            var type = $(this).data('value');
            $('.price_range input').prop('checked', false);
            $('.price_range').hide();
            $(`.price_range[data-value=${type}]`).show();
        })
        $('.search-type label:first').trigger('click');

        $('.banner-home-slider').owlCarousel({
        loop:true,
        autoplay: true,
        autoplayHoverPause:true,
        dots:false,
        nav:false,
        autoplayTimeout:10000,
        autoplaySpeed:1000,
        smartSpeed:1000,
        animateOut: 'fadeOut',
        responsive:{
            0:{
                items:1,
            },
        }

    });
    </script>

<?php $__env->stopSection(); ?>
<?php /**PATH /home/datnentayninh/domains/datnentayninh.org/public_html/resources/views/customer/contents/banner_home.blade.php ENDPATH**/ ?>