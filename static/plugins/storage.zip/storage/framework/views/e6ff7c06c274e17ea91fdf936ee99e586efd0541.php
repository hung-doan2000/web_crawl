<?php
    $user = auth()->user();
?>

<form class="bg-white" action="/tai-khoan/nap-tien" method="post">
    <?php echo csrf_field(); ?>
    <div class="col-12 p-2 bg-white mb-2 d-flex align-items-center justify-content-between">
        <h3 class=" text-secondary m-0">Nạp tiền vào tài khoản</h3>
    </div>

    <div class="row payment-info p-3">
            <div class="form-group col-md-6">
                <label class="control-label" for="amount_of_money">Số tiền muốn nạp:</label>
                <input type="amount_of_money" class="form-control <?php $__errorArgs = ['amount_of_money'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="amount_of_money" placeholder="Tối thiểu 10.000đ" name="amount_of_money">
                <?php $__errorArgs = ['amount_of_money'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div id="" class="error invalid-feedback d-block">
                        <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group col-md-6">
                <label class="control-label" for="customer_name">Tên khách hàng: </label>
                <input type="text" class="form-control <?php $__errorArgs = ['customer_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="customer_name" placeholder="Nhập tên khách hàng" name="customer_name"
                value="<?php echo e($user->name ?? ''); ?>"
                >
                <?php $__errorArgs = ['customer_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div id="" class="error invalid-feedback d-block">
                        <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group col-md-6">
                <label class="control-label" for="customer_email">Email:</label>
                <input type="text" class="form-control <?php $__errorArgs = ['customer_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="customer_email" placeholder="Nhập email" name="customer_email"
                value="<?php echo e($user->email ?? ''); ?>"
                >
                <?php $__errorArgs = ['customer_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div id="" class="error invalid-feedback d-block">
                        <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group col-md-6">
                <label class="control-label" for="customer_phone">Số điện thoại:</label>
                <input type="text" class="form-control <?php $__errorArgs = ['customer_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="customer_phone" placeholder="Số điện thoại" name="customer_phone"
                value="<?php echo e($user->phone_number ?? ''); ?>"
                >
                <?php $__errorArgs = ['customer_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div id="" class="error invalid-feedback d-block">
                        <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group col-md-6">
                <label class="control-label" for="customer_message">Nội dung giao dịch:</label>
                <textarea  class="form-control <?php $__errorArgs = ['customer_message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="customer_message" placeholder="Nhập nội dung giao dịch" name="customer_message" cols="30" rows="7"></textarea>
                <?php $__errorArgs = ['customer_message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div id="" class="error invalid-feedback d-block">
                        <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
    </div>
    <div class="p-3">
        <div class="payment-wraper">
            <?php $__errorArgs = ['payment_method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div id="" class="error invalid-feedback d-block">
                        <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php $__errorArgs = ['bank_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div id="" class="error invalid-feedback d-block">
                        <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div class="payment-method">
                <div class="method-image">
                    <img src="/images/Logo-VNPAYQR.png" alt="" srcset="">
                </div>
                <div class="method-content">
                    <strong>Chọn hình thức thanh toán online</strong> <br>
                    <span>Sử dụng điện thoại quét mã QR hoặc nạp trược tiếp trên ứng dụng VnPay.</span>
                </div>
                <div>
                    <div class="method-checkbox"><input type="radio" checked name="payment_method" value="1"></div>
                </div>
            </div>
            <div class="bank-list payment-body p-2 w-100">
                <div class="row p-0 m-0 bg-white ">
                    <?php $__currentLoopData = $vnpay_banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-2 col-md-3 col-4 bank-select border p-0 m-md-1">
                        <input class="d-none" type="radio" id="<?php echo e($bank->code); ?>" value="<?php echo e($bank->code); ?>" name="bank_code">
                        <label class="d-block m-0 p-2 w-100 h-100" for="<?php echo e($bank->code); ?>"><img class="img-fluid" src="<?php echo e($bank->avatar); ?>" alt=""></label>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>

        <div class="payment-wraper">
            <div class="payment-method">
                <div class="method-image">
                    <img src="https://sosanhnha.com/quanly/images/bank.jpg" alt="" srcset="">
                </div>
                <div  class="method-content">
                    <strong>Chọn hình nạp qua chuyển khoản trực tiếp</strong> <br>
                    <span>Sử dụng phương thức chuyển tiền qua tài khoản cá nhân của quản trị viên</span>
                </div>
                <div>
                    <div class="method-checkbox"><input type="radio" <?php if(old('payment_method') == 5): ?> checked <?php endif; ?> name="payment_method" value="5"></div>
                </div>
            </div>
            <div class="bank-list payment-body p-3">
                <?php $__currentLoopData = $bank_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="bank-details p-2">
                        <div class="bank-details-head">
                            <div style="width: 60px">
                                <img src="<?php echo e(explode(',',$bank->bank_avatar)[0] ?? ''); ?>" alt="">
                            </div>
                            <div class="pl-3"><strong><?php echo e($bank->bank_name); ?></strong></div>
                        </div>
                        <div class="bank-content">
                            <div><label>Số tài khoản: </label><span><?php echo e($bank->bank_account ?? ''); ?></span></div>
                            <div><label>Chủ tài khoản: </label><span><?php echo e($bank->bank_owner ?? ''); ?></span></div>
                            <div><label>Chi nhánh: </label><span><?php echo e($bank->bank_branch ?? ''); ?></span></div>
                            <div><label>Số điện thoại: </label><span><?php echo e($bank->owner_phone ?? ''); ?></span></div>
                            <div><label>Email: </label><span><?php echo e($bank->owner_email ?? ''); ?></span></div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <input type="hidden" name="recaptcha" id="recaptcha">
    <button type="submit" class="btn btn-success w-100 rounded-0 mb-0"><strong>NẠP TIỀN</strong></button>
</form>

<?php $__env->startSection('script'); ?>
##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##
<script src="https://www.google.com/recaptcha/api.js?render=<?php echo e(env('GOOGLE_RECAPCHA_CLIENT')); ?>"></script>
<script>
    grecaptcha.ready(function() {
        grecaptcha.execute('<?php echo e(env('GOOGLE_RECAPCHA_CLIENT')); ?>', {action: 'contact'}).then(function(token) {
            if (token) {
                document.getElementById('recaptcha').value = token;
            }
        });
    });
    $('[name=payment_method]').on('change', function(){
        $('.payment-wraper').removeClass('active');
        $('[name=payment_method]:checked').closest('.payment-wraper').addClass('active');
    });
    $('[name=payment_method]:checked').closest('.payment-wraper').addClass('active');
</script>
<?php $__env->stopSection(); ?>
<?php /**PATH /home/datnentayninh/domains/datnentayninh.org/public_html/resources/views/customer/user_profile/form/recharge_form.blade.php ENDPATH**/ ?>