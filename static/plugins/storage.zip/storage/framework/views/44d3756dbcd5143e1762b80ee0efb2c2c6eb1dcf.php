<div class="col-md-9">
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Thông tin tag</h3>
            <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i
                        class="fas fa-minus"></i>
                </button>
            </div>
        </div>
        <!-- /.card-header -->
        <div class="card-body">
            <div class="form-group">
                <label for="tag_name">Tên tag (<span class="text-red">*</span>)</label>
                <input
                name="name"
                type="text"
                class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                id="tag_name"
                placeholder="Nhập tên tag"
                value="<?php echo e($tag->name ?? old('name')); ?>"
                >
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div id="" class="error invalid-feedback d-block">
                        <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-6 form-group">
                <label for="type">Loại tag (<span class="text-red">*</span>)</label>
                <select class="form-control" name="type" id="type">
                    <option value="post" <?php if(isset($tag) && $tag->type == 'post'): ?> selected <?php endif; ?> >Bài viết</option>
                    <option value="realty" <?php if(isset($tag) && $tag->type == "realty"): ?> selected <?php endif; ?> >Bài rao bất động sản</option>
                </select>
            </div>
        </div>
        <!-- /.card-body -->
    </div>
</div>
<div class="col-md-3">
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Thao tác</h3>
            <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i
                        class="fas fa-minus"></i>
                </button>
            </div>
        </div>
        <div class="card-body">
            <div class="btn-set">
                <button type="submit" name="submit" value="save" class="btn btn-info">
                    <i class="fa fa-save"></i> Lưu
                </button>
                &nbsp;
                <button type="submit" name="submit" value="apply" class="btn btn-success">
                    <i class="fa fa-check-circle"></i> Lưu &amp; Thoát
                </button>
            </div>
        </div>
    </div>

</div>

<?php $__env->startSection('script'); ?>
    <script>
        // get slug
        $('#tag_name').on('blur', function () {
        getSlug('post_tag', $(this).val(), $('#slug'));
        });
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH /home/datnentayninh/domains/datnentayninh.org/public_html/resources/views/admin/pages/tags/form.blade.php ENDPATH**/ ?>