<!DOCTYPE html>
    <html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

    <?php echo $__env->make('customer.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <body class="loaded">
        <div id="loader-wrapper">
            <div class="loader-background"></div>
            <div id="loader"></div>
        </div>
        <?php echo $__env->make('customer.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Nội dung conter -->
         <div id="main-site">
            <?php echo $__env->yieldContent('content'); ?>
         </div><!--  end -->

        <!-- chân trang -->
        <?php echo $__env->make('customer.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('customer.partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </body>
    <!-- js -->
</html>
<?php /**PATH /home/datnentayninh/domains/datnentayninh.org/public_html/resources/views/customer/layouts/main.blade.php ENDPATH**/ ?>