<?php $__env->startSection('form'); ?>
<form action="<?php echo e(route('customer.realty_post.update', $realty_post->id)); ?>" method="POST" class="info-credibility form-news p-3">
    <?php echo csrf_field(); ?>
    <?php echo $__env->make('customer.pages.realty_post.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</form>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('customer.user_profile.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/datnentayninh/domains/datnentayninh.org/public_html/resources/views/customer/user_profile/update_post.blade.php ENDPATH**/ ?>