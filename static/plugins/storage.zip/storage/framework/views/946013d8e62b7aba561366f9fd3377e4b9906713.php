<div class="breadcrumbs">
    <a class="text-secondary" href="/">Trang chủ</a>
    <?php if(!empty($links)): ?>
        /
    <?php endif; ?>
    <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index =>  $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($index !== 0): ?>
     /
    <?php endif; ?>
    <a class="text-secondary" href="<?php echo e($item['link']); ?>"><?php echo e($item['name']); ?></a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


<?php /**PATH /home/datnentayninh/domains/datnentayninh.org/public_html/resources/views/customer/components/Breadcrumbs/realty_post_breadcrum.blade.php ENDPATH**/ ?>