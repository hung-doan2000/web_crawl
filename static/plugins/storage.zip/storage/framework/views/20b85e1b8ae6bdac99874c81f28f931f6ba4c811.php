<div class="modal modal-login fade" id="forgot-password" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content p-3">
        <div class="logo-login text-center">
            <img src="<?php echo e(asset('images/logo.png')); ?>" alt="">
        </div>
        <div class="pt-2 text-center">
            <strong class="text-blue-dark font-13">Quên mật khẩu?</strong>
            <p class="text-secondary font10">Nhập địa chỉ email bạn đã đăng ký, chúng tôi sẽ giúp bạn lấy lại mật khẩu</p>
        </div>
        <form action="/forgot-password" method="POST" id="forgotPassword" class="forgotPassword">
          <?php echo csrf_field(); ?>
          <div class="form-group">
            <div class="bl-div div-email">
              <input id="forgot_input" name="email_reset" title="Vui lòng nhập giá trị" type="text" class="form-control" placeholder="Nhập Email">
              <?php $__errorArgs = ['email_reset'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="errors_input text-danger">
                <?php echo e(__($message)); ?>

              </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

              <?php if(session()->has('status')): ?>
              <div class="errors_input text-success">
                <?php echo e(__(session()->get('status'))); ?>

              </div>
              <?php endif; ?>
            </div>
          </div>
          <div class="form-group">
            <button type="submit" class="btn login-btn w-100" id="continue-forgot-password">Gửi mật khẩu cho tôi</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<?php $__env->startSection('script'); ?>
    ##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##
    <?php if($errors->has('email_reset') || session()->has('status')): ?>
        <script>
        $(document).ready(function(){
        $('#forgot-password').modal('toggle');
        });
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php /**PATH /home/datnentayninh/domains/datnentayninh.org/public_html/resources/views/customer/auth/forgot-password.blade.php ENDPATH**/ ?>