<?php $__env->startSection('title'); ?>
    Sửa bài viết
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.partials.content_header', ['title' => 'Cập nhật bài viết'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="content" >
    <div class="container-fluid ">
        <form action="<?php echo e(route('admin.post.update', $post->id)); ?>" method="post" class="row">
            <?php echo csrf_field(); ?>
            <?php echo $__env->make('admin.pages.posts.form', ['post' => $post], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </form>

    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('/template/ckeditor/ckeditor.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.main_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/datnentayninh/domains/datnentayninh.org/public_html/resources/views/admin/pages/posts/edit.blade.php ENDPATH**/ ?>