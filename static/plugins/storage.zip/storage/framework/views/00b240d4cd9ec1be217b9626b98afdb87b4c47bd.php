
<!--message-->


<?php $__env->startSection('script'); ?>
##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##
<link rel="stylesheet" href="<?php echo e(asset('template\AdminLTE\plugins\sweetalert2\sweetalert2.min.css')); ?>">
<script src="<?php echo e(asset('template\AdminLTE\plugins\sweetalert2\sweetalert2.all.min.js')); ?>"></script>
<script>
    function swalAlert(message, type = 'success'){
        const Toast = Swal.mixin({
            showConfirmButton: false,
            timer: 3000,
        });

        Toast.fire({
            type: type,
            icon: type,
            title: message,
        })
    }
</script>

<?php if(session()->has('reset_status')): ?>
    ##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##
    <script>
        swalAlert('Cập nhật thành công mật khẩu mới');
    </script>
<?php endif; ?>

<?php if(session()->has('success')): ?>
##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##

<script type="text/javascript">
  const Toast = Swal.mixin({
    showConfirmButton: false,
    timer: 3000,
  });

  Toast.fire({
    type: 'success',
    icon: 'success',
    title: '<?php echo session()->get('success'); ?>'
  })
</script>
<?php endif; ?>

<?php if(session()->has('error')): ?>
##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##

<script type="text/javascript">
  const Toast = Swal.mixin({
    showConfirmButton: false,
    timer: 3000
  });

  Toast.fire({
    type: 'error',
    icon: 'error',
    title: '<?php echo session()->get('error'); ?>'
  })
</script>
<?php endif; ?>

<?php if(session()->has('warning')): ?>
##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##

<script type="text/javascript">
  const Toast = Swal.mixin({
    showConfirmButton: false,
    timer: 3000
  });

  Toast.fire({
    type: 'warning',
    icon: 'warning',
    title: '<?php echo session()->get('warning'); ?>'
  })

  //===============Toast function================//

</script>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php /**PATH /home/datnentayninh/domains/datnentayninh.org/public_html/resources/views/customer/partials/alert.blade.php ENDPATH**/ ?>