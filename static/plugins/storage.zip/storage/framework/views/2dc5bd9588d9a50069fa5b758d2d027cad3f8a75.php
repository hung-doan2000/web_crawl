 <!-- POpup RE-PASSWORD Phone -->
<div class="modal fade modal-popup"
    data-backdrop="static"
    data-keyboard="false"
    id="popup-re-password-email"
    tabindex="-1"
    role="dialog"
>
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="logo-login text-center mt-3">
                <img src="<?php echo e(asset('images/logo.png')); ?>" alt="">
            </div>
            <div class="modal-body">
                <p class="p-text text-center">Nhập lại mật khẩu mới và xác nhận để thay đổi</p>
                <form class="form-user-re-pass" id="form-user-re-pass" action="<?php echo e(route('customer.password.update')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="token" value="<?php echo e(old('token') ?? session()->get('reset_token')); ?>">

                    <div class="form-group">
                        <div class="bl-div div-email">
                          <input type="email" name="reset_email" class="form-control" value="<?php echo e(old('reset_email')); ?>" placeholder="Email">
                        </div>
                        <div class="errors_input text-danger">
                            <?php $__errorArgs = ['reset_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="bl-div div-password"> <input id="user_pass" name="reset_password"
                                type="reset_password" class="form-control" placeholder="Mật khẩu mới" /> <span
                                class="span-eyes"></span> </div>
                        <div class="errors_input text-danger">
                            <?php $__errorArgs = ['reset_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="bl-div div-password"> <input id="user_repass" name="reset_password_confirmation"
                                type="password" class="form-control"
                                placeholder="Nhập lại mật khẩu mới" /> <span class="span-eyes"></span>
                        </div>
                        <div class="errors_input text-danger">
                            <?php $__errorArgs = ['reset_password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group text-center"> <button id="save-user-change-pass" class="btn btn-info">Thay đổi mật khẩu</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div><!-- end -->

<?php if(session()->has('reset_token') ||  $errors->has('reset_password') ||  $errors->has('password_reset') || $errors->has('reset_password_confirmation') ||  $errors->has('reset_email') ): ?>
    <?php $__env->startSection('script'); ?>
    ##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##
        <script>
        $(document).ready(function(){
            $('#popup-re-password-email').modal('toggle');
        });
        </script>
    <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php /**PATH /home/datnentayninh/domains/datnentayninh.org/public_html/resources/views/customer/auth/reset_pasword.blade.php ENDPATH**/ ?>