<div class="p-3 rounded bg-white border">
    <h3 class="font-12 py-2 border-bottom">
        Nhà đất tại Tây Ninh
    </h3>
    <div class="">
        <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a class="d-block secondary-text py-1 font-9" href="/<?php echo e($item->slug); ?>"><?php echo e($item->name_with_type); ?> (<?php echo e($item->realty_posts_count); ?>)</a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>


<?php if(isset($featured_posts)): ?>
<div class="rounded  p-3 my-3 border bg-white" >
    <h3 class="font-12 py-2 border-bottom uppercase">Tin xem nhiều nhất</h3>
    <?php $__currentLoopData = $featured_posts->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="">
        <a class=" d-inline-block py-2 font-9 sidebar-post-link secondary-text" href="<?php echo e(route('customer.post.show',['cat_slug' => $item->categories->first()->slug ?? 'danh-muc', 'post_slug' => $item->slug] )); ?>"> <?php echo e($item->name); ?> </a>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>

<?php $__env->startSection('script'); ?>
    ##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##
    <script>
        $('.sidebar-post-link').each(function(){
            maxText($(this), 60);
        })
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH /home/datnentayninh/domains/datnentayninh.org/public_html/resources/views/customer/pages/realty_post/sidebar.blade.php ENDPATH**/ ?>