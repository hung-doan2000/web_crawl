<?php $__env->startSection('preset_seo'); ?>
    <?php
        $custom_title = 'Trang chủ bất động sản Tây Ninh';
        $custom_description = 'Trang chủ bất động sản Tây Ninh';
    ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
  <?php echo e($seo->title ?? 'Trang chủ'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
Trang chủ
<?php $__env->stopSection(); ?>

 <?php $__env->startSection('content'); ?>

    <?php echo $__env->make('customer.contents.banner_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('customer.contents.list_bds_hot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('customer.contents.home_post_v2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('customer.contents.hot_realty', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if($home_projects->isNotEmpty()): ?>
        <?php echo $__env->make('customer.contents.home_project_v2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <section class="container">
        <div class="d-flex">
            <h3 class="font-18 home-title color-dark">Doanh nghiệp nổi bật</h3>
        </div>
        <div class="owl-carousel partner-slider mb-5">
            <?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item d-flex align-items-center  p-2" style="height: 120px;" >
                    <div class="w-100 border h-100 p-2 partner-item">
                        <img style="height: 100%; object-fit:contain" src="<?php echo e($partner->logo); ?>" alt="">
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
    <?php if(isset($horizontal_advertisments)): ?>
        <?php echo $__env->make('customer.components.advertisments.horizontal', ['items' => $horizontal_advertisments], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##
<script>
    $('.horizon-advertisment').owlCarousel({
        loop:true,
        autoplay: true,
        autoplayTimeout:5000,
        autoplayHoverPause:true,
        dots:false,
        nav:false,
        autoplayTimeout:10000,
        autoplaySpeed:1000,
        smartSpeed:1000,
        animateOut: 'fadeOut',
        responsive:{
            0:{
                items:1,
            },
        }
    });

    $('.vertical-advertisment').owlCarousel({
        loop:true,
        autoplay:true,
        autoplayTimeout:5000,
        autoplayHoverPause:true,
        dots:false,
        nav:false,
        autoplayTimeout:10000,
        autoplaySpeed:1000,
        smartSpeed:1000,
        animateOut: 'fadeOut',
        responsive:{
            0:{
                items:1,
            },
        }
    });

    $('.partner-slider').owlCarousel({
    loop:true,
    margin:10,
    nav:true,
    dot:false,
    autoplay:true,
    slideTransition: 'linear',
    smartSpeed:3000,
    autoplayTimeout:3050,
    navText:["<div class='owl-nav-btn prev-slide'><i class='fas fa-chevron-left'></i></div>","<div class='owl-nav-btn next-slide'><i class='fas fa-chevron-right'></i></div>"],
    responsive:{
        0:{
            items:2
        },
        600:{
            items:3
        },
        1000:{
            items:6
        }
    }
})
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('customer.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/datnentayninh/domains/datnentayninh.org/public_html/resources/views/customer/home.blade.php ENDPATH**/ ?>