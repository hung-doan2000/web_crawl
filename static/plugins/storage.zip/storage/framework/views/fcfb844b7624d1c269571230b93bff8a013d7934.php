<?php $__env->startSection('title'); ?>
Tin tức bất động sản
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="blog-wrapper blog-post hrm-bg-secondary">
	<div class="container pt-3">
        <?php echo e(\App\Helpers\Breadcrumbs\PostBreadcrumbHelper::render($post_categories->first())); ?>


		<div class="entry-head my-3">
			<h1 class="font-15 entry-title"><?php echo e($category->name); ?></h1>
		</div>
		<div class="row m-0">
			<div class="col-md-8 bg-white">
                <?php if(Agent::isDesktop()): ?>
                    <div class="list-blog-post p-3">
                        <div class="owl-carousel head-posts">
                            <?php $__currentLoopData = $posts->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $top_post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('customer.post.show', ['cat_slug' => $category->slug, 'post_slug' => $top_post->slug] )); ?>" class="item d-block position-relative">
                                <div class="embed-responsive embed-responsive-16by9 img-wraper">
                                    <img class="embed-responsive-item" src="<?php echo e($top_post->avatar ?? ''); ?>" alt="<?php echo e($top_post->name ?? ''); ?>">
                                </div>
                                <div class="position-absolute w-100 head-posts-title text-light p-3" style="bottom:0">
                                    <h2 class="font-14"><?php echo e($top_post->name); ?></h2>
                                    <div class="font-10 text-light">
                                        <i class="far fa-calendar"></i>
                                        <span><?php echo e(\App\Helpers\TimeHelper::getDateBeautyString($top_post->created_at)); ?></span>
                                    </div>
                                </div>
                            </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endif; ?>

                <div>
                    <?php $__currentLoopData = Agent::isDesktop() ? $posts->skip(3) : $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="category-blog p-3 rounded-1 bg-white">
                            <div class="top-post row">
                                <div class="col-md-5 col-3 p-0 px-md-3">
                                    <a class="d-block rounded-1 img-wraper" href="<?php echo e(route('customer.post.show',['cat_slug' => $post->categories->first()->slug ?? 'danh-muc', 'post_slug' => $post->slug] )); ?>">
                                        <img style="max-height: 175px" class="rounded" src="<?php echo e($post->thumb ?? ''); ?>" alt="<?php echo e($post->name ?? ''); ?>">
                                    </a>
                                </div>
                                <div class="post-link col-sm-7 col-9 pl-md-0 ">
                                    <a style="font-weight: 500" class="font-10 font-md-12 text-dark post-title" href="<?php echo e(route('customer.post.show',['cat_slug' => $post->categories->first()->slug ?? 'danh-muc', 'post_slug' => $post->slug] )); ?>"><?php echo e(Str::limit($post->name, 45, '...')); ?></a>
                                    <div class="mt-2 d-md-block d-none">
                                        <span class="font-9 post-description ">
                                            <?php echo e($post->short_description); ?>

                                        </span>
                                    </div>
                                    <div class="cl-main-text mt-1 font-9 text-muted">
                                        <?php echo e(App\Helpers\TimeHelper::getDateDiffFromNow($post->created_at)['string'] ?? ''); ?> trước
                                    </div>
                                </div>
                            </div>
                        </div>
                        <hr class="my-1">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php echo e($posts->links()); ?>

            </div>
                <?php echo $__env->make('customer.pages.posts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    ##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##
    <script>
        $('.post-title').each(function(){
            maxText($(this), 60);
        })

        $('.post-description').each(function(){
            maxText($(this), 180);
        })

        $('.head-posts').owlCarousel({
            loop:true,
            autoplay:false,
            autoplayTimeout:2000,
            autoplayHoverPause:true,
            margin: 20,
            dots:false,
            nav:true,
            autoplayTimeout:3000,
            autoplaySpeed:1200,
            smartSpeed:1200,
            navText:["<div class='owl-nav-btn prev-slide'><i class='fas fa-chevron-left'></i></div>","<div class='owl-nav-btn next-slide'><i class='fas fa-chevron-right'></i></div>"],
            responsive:{
                0:{
                    items:1,
                }
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/datnentayninh/domains/datnentayninh.org/public_html/resources/views/customer/pages/posts/list_by_category.blade.php ENDPATH**/ ?>