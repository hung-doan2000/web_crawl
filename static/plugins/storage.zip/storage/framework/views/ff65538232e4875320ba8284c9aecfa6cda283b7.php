<textarea name="<?php echo e($name); ?>" class="form-field <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="<?php echo e($id); ?>" rows="10" cols="80">
    <?php echo e($current_input); ?>

</textarea>

<?php $__env->startSection('script'); ?>
    ##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##
    <script>
        var <?php echo e($id); ?> =  CKEDITOR.replace('<?php echo e($id); ?>', ckeditor_options);
    </script>
<?php $__env->stopSection(); ?><?php /**PATH /home/datnentayninh/domains/datnentayninh.org/public_html/resources/views/admin/components/ckeditor.blade.php ENDPATH**/ ?>