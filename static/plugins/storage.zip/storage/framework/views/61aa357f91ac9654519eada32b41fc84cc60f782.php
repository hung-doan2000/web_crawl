<?php $__env->startSection('css'); ?>
##parent-placeholder-2f84417a9e73cead4d5c99e05daff2a534b30132##
<link rel="stylesheet" href="<?php echo e(asset('template/AdminLTE/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('template/AdminLTE/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
<?php $__env->stopSection(); ?>

<div class="col-12 p-2 bg-white mb-2 d-flex align-items-center justify-content-between">
    <h3 class=" text-secondary m-0">Tài khoản cá nhân</h3>
    <a href="/tai-khoan/nap-tien" class="btn btn-save hrm-btn-info-solid"><strong>Nạp tiền</strong></a>
</div>
<div class="account-balance-wraper row p-3">
    <div>
        <div class=" ">
            <div class="account-balance bg-white font-13 p-2">
                <span class="text-secondary"> Số dư tài khoản:</span> <strong class="text-blue"><?php echo e(number_format($wallet->main_account ?? 0, 0,0, '.')); ?>VNĐ</strong>
            </div>
        </div>
    </div>
</div>

<div class="history-table w-100 pt-5 px-3 bg-white">
    <table id="account-balance-table" class="table table-bordered table-hover ">
        <thead>
          <tr>
              <th>Thời gian</th>
              <th>Mô tả</th>
              <th>Biến động</th>
              <th>Số dư</th>
          </tr>
        </thead>
        <tbody class="font-9">
            <?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $properties = $item->properties;
            ?>
            <tr>
                <td><?php echo e(Carbon\Carbon::parse($item->created_at)->format('d/m/Y H:i')); ?></td>
                <td><?php echo e($item->description); ?></td>
                <td><?php echo e($properties['amount_of_money'] ?? 0); ?> VNĐ</td>
                <td><?php echo e($properties['main_account'] ?? 0); ?> VNĐ</td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php $__env->startSection('script'); ?>
    ##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##
    <script src="<?php echo e(asset('template/AdminLTE/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('template/AdminLTE/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('template/AdminLTE/plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('template/AdminLTE/plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
    <script>
        $("#account-balance-table").dataTable( {"order": [[ 0, "desc" ]]});
       </script>
<?php $__env->stopSection(); ?>
<?php /**PATH /home/datnentayninh/domains/datnentayninh.org/public_html/resources/views/customer/user_profile/form/account_balance.blade.php ENDPATH**/ ?>