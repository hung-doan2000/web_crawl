<?php $__env->startSection('form'); ?>
    <div>
        <h1>Xác nhận nạp tiền</h1>

        <p>Chúng tôi đã nhân được yêu cầu nạp tiền của bạn!</p>
        <p>Để nạp tiền, quý khách hãy chuyển tiền đến tài khoản phía trên kèm tin nhắn là chuỗi ký tự sau:</p>
        <h2><?php echo e($bill->bill_code); ?></h2>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('customer.user_profile.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/datnentayninh/domains/datnentayninh.org/public_html/resources/views/customer/user_profile/bill_confirm.blade.php ENDPATH**/ ?>