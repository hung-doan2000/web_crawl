<?php echo $__env->yieldContent('preset_seo'); ?>
<?php
    $full_url = request()->fullUrl();
    $site_name = env('APP_NAME');
?>

<meta name="title" itemprop='description' content="<?php echo e($seo->title ?? $custom_title ?? ''); ?>" />
<meta name="description" content="<?php echo e($seo->description ?? $custom_description ?? ''); ?>" />
<meta name="url" content="<?php echo e($seo->url ?? $full_url); ?>" />
<meta name="keywords" content="<?php echo e($seo->keywords ?? $custom_keywords ?? ''); ?>" />
<meta property="og:title" content="<?php echo e($seo->og_title ?? $custom_title ?? ''); ?>" />
<meta property="og:url" content="<?php echo e($seo->og_url ?? $full_url); ?>" />
<meta property="og:type" content="<?php echo e($seo->og_type ?? 'website'); ?>" />
<meta property="og:description" content="<?php echo e($seo->og_description ?? $custom_description ?? ''); ?>"/>
<meta property="og:image" content="<?php echo e($seo->og_image ?? $custom_og_image ?? ''); ?>" />
<meta property="og:site_name" content="<?php echo e($seo->og_site_name ?? $site_name); ?>" />
<meta property="twitter:card" content="<?php echo e($seo->tw_card ??  ''); ?>" />
<meta property="twitter:title" content="<?php echo e($seo->tw_title ?? $custom_title ?? ''); ?>" />
<meta property="twitter:description" content="<?php echo e($seo->tw_description ?? $custom_description ?? ''); ?>" />
<meta property="twitter:image" content="<?php echo e($seo->tw_image ?? $custom_og_image ?? ''); ?>" />
<meta property="twitter:site" content="<?php echo e($seo->tw_site_name ?? $site_name); ?>" />
<meta property="twitter:url" content="<?php echo e($seo->tw_url ?? $full_url); ?>" />

<?php if(isset($seo->ld_json)): ?>
<script type="application/ld+json">
    <?php echo $seo->ld_json; ?>

</script><!--meta_ants-->
<?php endif; ?>
<?php /**PATH /home/datnentayninh/domains/datnentayninh.org/public_html/resources/views/seo_manager/seo_frontend_component.blade.php ENDPATH**/ ?>