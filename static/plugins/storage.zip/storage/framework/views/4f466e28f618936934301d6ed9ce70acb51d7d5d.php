<div class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1 class="m-0 text-dark"><?php echo e($title ?? 'Admin'); ?></h1>
      </div><!-- /.col -->
      
      </div><!-- /.col -->
    </div><!-- /.row -->
  </div><!-- /.container-fluid -->
</div><?php /**PATH /home/datnentayninh/domains/datnentayninh.org/public_html/resources/views/admin/partials/content_header.blade.php ENDPATH**/ ?>