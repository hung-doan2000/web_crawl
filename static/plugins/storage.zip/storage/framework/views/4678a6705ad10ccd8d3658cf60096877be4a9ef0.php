<section class="home-post py-3 py-lg-5 section bg-white">
	<div class="container">
        <div class="row p-0">
            <div class="col-md-9 home-posts">
                <ul class="nav border-bottom mb-3">
                    <?php $__currentLoopData = $home_featured_cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index =>  $post_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="nav-item mr-4">
                        <a class="nav-link font-16 text-secondary home-title px-0 <?php if($index == 0): ?> active <?php endif; ?>" data-toggle="tab" href="#cat<?php echo e($post_category->id); ?>"><strong><?php echo e($post_category->name); ?></strong></a>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <li class="ml-auto d-flex align-items-center">
                        <a href="/tin-tuc" class="text-dark">Xem tất cả <i class="fas fa-long-arrow-alt-right"></i></a>
                    </li>
                </ul>

                <!-- Tab panes -->
                <div class="tab-content">
                    <?php $__currentLoopData = $home_featured_cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index =>  $post_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="tab-pane <?php if($index == 0): ?> active <?php else: ?> fade <?php endif; ?>  p-0" id="cat<?php echo e($post_category->id); ?>">
                        <div class="row">
                            <?php
                                $top_post = $post_category->posts->first();
                                if ($top_post) {
                                    $link = route('customer.post.show',['cat_slug' => $post_category->slug ?? 'danh-muc', 'post_slug' => $top_post->slug] );
                                }
                            ?>
                            <div class="col-md-6">
                                <?php if($top_post): ?>
                                <a href=""class="d-block img-wraper rounded pt-2 mb-3" style="overflow:hidden">
                                    <img class="img-fluid" style="height: 264px" src="<?php echo e($top_post->thumb ?? ''); ?>" alt="" srcset="">
                                </a>
                                <a class="font-14 main-text"  href="<?php echo e($link ?? '#'); ?>"><strong class="mt-3"> <?php echo e($top_post->name); ?></strong></a>
                                <p class="pt-2 text-secondary"><i class="far fa-clock"></i> <?php echo e(App\Helpers\TimeHelper::getDateDiffFromNow($top_post->created_at)['string'] ?? ''); ?> trước</p>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6">
                                <?php $__currentLoopData = $post_category->posts->skip(1)->take(7); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $link = route('customer.post.show',['cat_slug' => $post_category->slug ?? 'danh-muc', 'post_slug' => $post->slug] )
                                    ?>
                                    <div class="row mb-3 mb-md-0 px-2 ">
                                        <a href="<?php echo e($link); ?>" class="col-4 d-md-none d-block embed-responsive embed-responsive-16by9">
                                            <img class="embed-responsive-item" src="<?php echo e($post->thumb); ?>" alt="<?php echo e($post->name); ?>">
                                        </a>
                                        <a class="col-8 font-md-10 col-md-12 pl-2 d-block w-75 secondary-text border-md-bottom py-2" href="<?php echo e($link); ?>">
                                            <span class="font-9 font-md-11 font-weight-md-400 font-weight-600"><?php echo e(Str::limit($post->name, 70, "...")); ?></span>
                                            <span class="d-block pt-1 font-8 d-md-none text-secondary"><i class="far fa-clock"></i> <?php echo e(App\Helpers\TimeHelper::getDateDiffFromNow($post->created_at)['string'] ?? ''); ?> trước</span>
                                        </a>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="col-md-3 pt-3">
                <?php if(isset($vertical_advertisments)): ?>
                    <?php echo $__env->make('customer.components.advertisments.vertical', ['items' => $vertical_advertisments], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
            </div>
        </div>
	</div>
</section>
<?php /**PATH /home/datnentayninh/domains/datnentayninh.org/public_html/resources/views/customer/contents/home_post_v2.blade.php ENDPATH**/ ?>