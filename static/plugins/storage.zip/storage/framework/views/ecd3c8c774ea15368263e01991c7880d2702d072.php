<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" type="image/png" href="<?php echo e(Str::replaceLast(',', '', $theme_options['favicon'] ?? '')); ?>"/>
    <meta name="author" content="ThemeStarz">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="google-site-verification" content="FmPO275g37H5kixUCgMLJmeKmuYpk-ZX5SXaa6iFhGU" />
    <?php echo $__env->make('seo_manager.seo_frontend_component', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <link href='http://fonts.googleapis.com/css?family=Roboto:300,400,500,600,700' rel='stylesheet' type='text/css'>

    <?php echo $__env->make('customer.partials.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<?php /**PATH /home/datnentayninh/domains/datnentayninh.org/public_html/resources/views/customer/partials/head.blade.php ENDPATH**/ ?>