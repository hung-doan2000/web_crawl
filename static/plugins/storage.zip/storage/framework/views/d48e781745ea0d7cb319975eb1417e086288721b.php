<?php $__env->startSection('css'); ?>
##parent-placeholder-2f84417a9e73cead4d5c99e05daff2a534b30132##
<style>
    .sidebar-post-link{
        color: #222d44;
        font-weight: 600;
    }
</style>
<?php $__env->stopSection(); ?>

    
    <?php if(isset($featured_realties)): ?>
        <div class="rounded-1 bg-white p-3 mb-3" >
            <h4 class="uppercase font-w-600">Nhà đất nổi bật</h4>
            <div class="row px-2">
                <?php $__currentLoopData = $featured_realties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-6 p-2">
                    <a href="<?php echo e($item->link); ?>" class="d-block position-relative img-wraper">
                        <img src="<?php echo e($item->thumb); ?>" style="height: 130px" alt="<?php echo e($item->name); ?>">
                        <div class="ribbon-wrapper ribbon">
                          <div class="ribbon bg-danger text-white">
                            HOT
                          </div>
                        </div>
                    </a>
                    <a class="d-block line-height-12 mt-2 text-secondary font-9" href="<?php echo e($item->link); ?>"><?php echo e(Str::limit($item->title, 35, ' ...')); ?></a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endif; ?>

    <?php if(isset($featured_provinces)): ?>
    <div class="rounded-1 bg-white p-3 mb-3 border-bottom" >
        <h4 class="uppercase font-w-600">Mua bán nhà đất tại Việt Nam</h4>
        <div class="row">
            <?php $__currentLoopData = $featured_provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-6 py-1">
                <a class="cl-light-blue font-9" href="/<?php echo e($province->slug ?? ''); ?>"><?php echo e($province->name); ?></a>
                <span class="font-9">(<?php echo e($province->realty_posts_count); ?>)</span>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <?php endif; ?>

    
    <div class="rounded-1 bg-white p-3 mb-3" >
        <h4 class="uppercase font-w-600">Chủ đề được yêu thích</h4>
        <?php if(isset($featured_tags)): ?>
        <?php $__currentLoopData = $featured_tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('customer.realty_tag.get_all', $tag->slug)); ?>" class="d-inline-block py-1 px-2 my-2 mr-2 hrm-btn-info-solid">
            <strong class="font-9">#<?php echo e($tag->name); ?></strong>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>


    
    <?php if(isset($featured_posts)): ?>
    <div class="rounded-1 bg-white p-3 mb-3 border-bottom" >
        <h4 class="font-w-600 uppercase">Tin hay cho bạn</h4>
        <?php $__currentLoopData = $featured_posts->skip(5)->take(5) ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="d-flex py-3 border-top">
            <a class="flex-fixed-width rounded-1 mr-3" href="<?php echo e(route('customer.post.show',['cat_slug' => $item->categories->first()->slug ?? 'danh-muc', 'post_slug' => $item->slug] )); ?>" class="rounded-1" style="width: 125px">
                <img style="width: 100px; height:70px" src="<?php echo e($item->thumb); ?>" alt="<?php echo e($item->name); ?>">
            </a>
            <div>
                <a class="font-10 sidebar-link text-secondary" href="<?php echo e(route('customer.post.show',['cat_slug' => $item->categories->first()->slug ?? 'danh-muc', 'post_slug' => $item->slug] )); ?>"> <?php echo e($item->name); ?> </a>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>

<?php $__env->startSection('script'); ?>
##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##
<script>
    $('.sidebar-link').each(function(){
        maxText($(this), 50);
    })
</script>
<?php $__env->stopSection(); ?>
<?php /**PATH /home/datnentayninh/domains/datnentayninh.org/public_html/resources/views/customer/components/sidebars/realty_sidebar.blade.php ENDPATH**/ ?>