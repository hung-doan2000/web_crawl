<?php $__env->startSection('css'); ?>
##parent-placeholder-2f84417a9e73cead4d5c99e05daff2a534b30132##
<style>
    .place-search-result{
        max-height: 300px;
        overflow-y: scroll;
    }
    .place-select{
        cursor: pointer;
    }
</style>
<?php $__env->stopSection(); ?>
<div class="row">
    <div class="col-12"><label>Địa chỉ BĐS</label></div>
    <div class="col-md-4 form-group">
        <select class="form-control address_input <?php $__errorArgs = ['province_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="province_code" id="province">
            <option value="">Tỉnh/Thành phố</option>
            <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option
            <?php if(isset($project) && $province->code == $project->province_code): ?> selected <?php endif; ?>
            value="<?php echo e($province->code); ?>"><?php echo e($province->name_with_type); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['province_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div id="" class="error invalid-feedback d-block">
                <?php echo e($message); ?>

        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-md-4 form-group">
        <select
        class="form-control address_input <?php $__errorArgs = ['district_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
        name="district_code" id="district"
        >
            <option value="">Huyện/Thị xã</option>
            <?php if(isset($districts)): ?>
                <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option
                <?php if($district->code == $project->district_code): ?> selected <?php endif; ?>
                value="<?php echo e($district->code); ?>"><?php echo e($district->name_with_type); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </select>
        <?php $__errorArgs = ['district_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div id="" class="error invalid-feedback d-block">
                <?php echo e($message); ?>

        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-md-4 form-group">
        <select class="form-control address_input <?php $__errorArgs = ['commune_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="commune_code" id="commune"
        >
            <option value="">Phường/Xã</option>
            <?php if(isset($communes)): ?>
            <?php $__currentLoopData = $communes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commune): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option
            <?php if($commune->code == $project->commune_code): ?> selected <?php endif; ?>
            value="<?php echo e($commune->code); ?>"><?php echo e($commune->name_with_type); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </select>
        <?php $__errorArgs = ['commune_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div id="" class="error invalid-feedback d-block">
                <?php echo e($message); ?>

        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>

<div class="row">
    <div class="col-md-8 form-group" style="position: relative; z-index:1000">
        <input
        autocomplete="none"
        type="text"
        id="street"
        class="form-control address_input"
        name="street"
        placeholder="Địa chỉ cụ thể"
        <?php if(isset($project)): ?>
        value="<?php echo e($project->street ?? ''); ?>"
        <?php endif; ?>
        >
        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div id="" class="error invalid-feedback d-block">
            <?php echo e($message); ?>

        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <ul class="place-search-result list-group" style="display: none; position:absolute; width:100%">
        </ul>
    </div>
</div>

<?php $__env->startSection('script'); ?>
##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##
<script defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDWTx7bREpM5B6JKdbzOvMW-RRlhkukmVE&callback=initMap"> </script>
    <script>
        async function getPlace(url) {
            let data = await fetch(url).then(res => res.json());
            return data;
        }

        function getFullAddress(){
            var address = $('[name="street"]').val() + ',' + $('#commune option:selected').text() + ',' + $('#district option:selected').text() + ',' + $('#province option:selected').text();
            address = address.replace('Phường/Xã', '');
            address = address.replace('Quận/Huyện', '');
            address = address.replace(/,+/g, ',');
            return address;
        }

        function setSelect(ggMapData){
            console.log(ggMapData);
            var places = '';
            ggMapData.results.forEach(element => {
                places += `<li class="place-select list-group-item p-2" data-name="${element.name}">${element.name}</li>`;
            });
            $('.place-search-result').html(places);
        }

        function initMap() {
            // The location of Uluru
            <?php if(isset($project)): ?>
            var current = {
                lat: <?php echo e($project->google_map_lat ?? 21.027964); ?>,
                lng: <?php echo e($project->google_map_lng ?? 105.8510132); ?>,
            };
            <?php else: ?>
            var current = {
                lat:  21.027964,
                lng: 105.8510132
            };
            <?php endif; ?>

            // The map, centered at Uluru
            var map = new google.maps.Map(
                document.getElementById('map'), { zoom: 17, center: current, optimized: true });
            // The marker, positioned at Uluru
            var marker = new google.maps.Marker({
                position: current,
                map: map,
                draggable: true,
            });
            map.addListener('mouseout', function () {
                $('[name="google_map_lat"]').val(marker.getPosition().lat());
                $('[name="google_map_lng"]').val(marker.getPosition().lng());
            });

            $('.address_input').on('blur', function(e){
                var address = getFullAddress();
                changeMarker(address);
            })

            function changeMarker(address){
                let link = `http://localhost:91/api/get-geo-by-mane?search_string=${address}`
                getPlace(link).then(data => {
                    geo = data.results[0].geometry.location;
                    marker.setPosition( new google.maps.LatLng( geo.lat, geo.lng));
                    map.panTo( new google.maps.LatLng( geo.lat, geo.lng ));
                    $('[name="google_map_lat"]').val(geo.lat);
                    $('[name="google_map_lng"]').val(geo.lng);
                });
            }
            var search;

            $('#street').on('input', function(e){
                var address = getFullAddress();
                let link = `http://localhost:91/api/get-geo-by-mane?search_string=${address}`;
                clearTimeout(search);
                search = setTimeout(function(){
                        var list_place = getPlace(link).then(data => {
                        setSelect(data);
                    });
                }, 300);
            })

            $('#street').on('blur', function(e) {
                setTimeout(function(){
                    $('.place-search-result').hide();
                }, 500)
            })

            $('#street').on('focus', function(e) {
                $('.place-search-result').show();
            })

            $(document).on('click', '.place-select', function(e){
                $('#street').val($(this).text());
            });
        }

        function getDistricts(province_code){
            url = '/get-district-of-province/' + province_code;
            return $.ajax({
                url: url,
                type: 'get',
            })
        }
        $('#province').on('change', function(){
            var province_code = $(this).val();
            var district_inputs = '<option value="">Quận/Huyện</option>';
            getDistricts(province_code)
            .done(function(data){
                data.forEach(element => {
                    district_inputs += `<option value="${element.code}">${element.name_with_type}</option>`;
                });
                $('#district').html(district_inputs);
                $('#commune').html('<option value="">Phường/Xã</option>');

            });
        })

        function getCommunes(district_code){
            url = '/get-commune-of-district/' + district_code;
            return $.ajax({
                url: url,
                type: 'get',
            })
        }

        $(document).on('change', "#district" , function(){
            var district_code = $(this).val();
            var commune_inputs = '<option value="">Phường/Xã</option>';
            getCommunes(district_code)
            .done(function(data){
                data.forEach(element => {
                    commune_inputs += `<option value="${element.code}">${element.name_with_type}</option>`;
                });
                $('#commune').html(commune_inputs);
            });
        })
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH /home/datnentayninh/domains/datnentayninh.org/public_html/resources/views/admin/pages/project/location_picker.blade.php ENDPATH**/ ?>