<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
      
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <link rel="shortcut icon" href="<?php echo e(asset('images/favicon.ico')); ?>">
    <title>
      <?php echo $__env->yieldContent('title'); ?>
    </title>
    <?php echo $__env->make('admin.partials.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </head>
<?php /**PATH /home/datnentayninh/domains/datnentayninh.org/public_html/resources/views/admin/partials/head.blade.php ENDPATH**/ ?>