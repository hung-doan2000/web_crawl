<?php $__env->startSection('title'); ?>
    Trang chủ
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<?php echo $__env->make('admin.partials.content_header', ['title' => 'Theme Options'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row px-4">
    <div class="col-5 col-sm-3">
        <div class="nav flex-column nav-tabs h-100" id="vert-tabs-tab" role="tablist" aria-orientation="vertical">
            <a class="nav-link active" id="vert-tabs-home-tab" data-toggle="pill" href="#vert-tabs-home" role="tab" aria-controls="vert-tabs-home" aria-selected="true">Cấu hình chung</a>
            <a class="nav-link" id="vert-tabs-profile-tab" data-toggle="pill" href="#vert-tabs-profile" role="tab" aria-controls="vert-tabs-profile" aria-selected="false">Logo</a>
            <a class="nav-link" id="vert-tabs-messages-tab" data-toggle="pill" href="#vert-tabs-messages" role="tab" aria-controls="vert-tabs-messages" aria-selected="false">Mạng xã hội</a>
            <a class="nav-link" id="vert-tabs-contact-tab" data-toggle="pill" href="#vert-tabs-contact" role="tab" aria-controls="vert-tabs-contact" aria-selected="false">Liên hệ</a>
        </div>
    </div>
    <div class="col-7 col-sm-9">
    <div class="tab-content" id="vert-tabs-tabContent">
        <form id="formEdit"  action="<?php echo e(route('admin.theme_option.store')); ?>" method="post">
            <div class="tab-content" id="vert-tabs-tabContent">
                <div class="tab-pane text-left fade show active" id="vert-tabs-home" role="tabpanel" aria-labelledby="vert-tabs-home-tab">
                    <?php echo $__env->make('admin.pages.theme_options.form.general', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="tab-pane fade" id="vert-tabs-profile" role="tabpanel" aria-labelledby="vert-tabs-profile-tab">
                    <?php echo $__env->make('admin.pages.theme_options.form.logo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="tab-pane fade" id="vert-tabs-messages" role="tabpanel" aria-labelledby="vert-tabs-messages-tab">
                    <?php echo $__env->make('admin.pages.theme_options.form.social', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>

                <div class="tab-pane fade" id="vert-tabs-contact" role="tabpanel" aria-labelledby="vert-tabs-contact-tab">
                    <?php echo $__env->make('admin.pages.theme_options.form.contact', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </form>
    </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    ##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##
    <script src="<?php echo e(asset('/template/ckeditor/ckeditor.js')); ?>"></script>
    <script>
    </script>
    <script>
        var formData = {};
        function loadEditField(key, value){
            formData[key] = value;
        }

        function storeData(data){
            $.ajax({
                url: "<?php echo e(route('admin.theme_option.store')); ?>",
                data: data,
                type: 'post',
                success: function(data){
                    console.log(data),
                    swalToast('Cập nhật thành công!');
                },
                error: function(data){

                }
            });
        }

        $('.form-field').on('change', function(){
            loadEditField($(this).attr('name'), $(this).val());
        });

        CKEDITOR.on('instanceReady', function(event) {
            var editor = event.editor;

            editor.on('change', function(event) {
                var name = this.name;
                var content = this.getData();
                loadEditField(name, content);
            });
        });

        $('.btnSave').on('click', function(){
            console.log(formData);
            storeData(formData);
            formData = {};
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.main_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/datnentayninh/domains/datnentayninh.org/public_html/resources/views/admin/pages/theme_options/index.blade.php ENDPATH**/ ?>