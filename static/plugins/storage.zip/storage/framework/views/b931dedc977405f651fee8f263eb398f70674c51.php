  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <strong>Copyright &copy; 2020 <a href="https://hamrongmedia.com">Hamrongmedia.com</a>.</strong>
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 1.0
    </div>
  </footer>
<?php /**PATH /home/datnentayninh/domains/datnentayninh.org/public_html/resources/views/admin/partials/footer.blade.php ENDPATH**/ ?>