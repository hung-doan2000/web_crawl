<div class="col-md-9">
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Thông tin Bất động sản</h3>
            <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i
                        class="fas fa-minus"></i>
                </button>
            </div>
        </div>
        <!-- /.card-header -->
        <div class="card-body">
            <div class="row">
                <div class="col-md-12 form-group">
                    <label for="">Tên dự án</label>
                    <input
                    id="name"
                    type="text"
                    class="form-control  <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    name="name"
                    placeholder="Tên dự án"
                    value="<?php echo e($project->name ?? old('name')); ?>"
                    >
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div id="" class="error invalid-feedback d-block">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-12 form-group">
                    <label for="">Slug</label>
                    <input
                    id="slug"
                    type="text"
                    class="form-control  <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    name="slug"
                    placeholder="Slug"
                    value="<?php echo e($project->slug ?? old('slug')); ?>"
                    >
                    <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div id="" class="error invalid-feedback d-block">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>



            <div class="row">
                <div class="col-md-6 form-group">
                    <label for="site_area">Diện tích tổng thể(<span class="text-red">*</span>)</label>
                    <input
                    name="site_area"
                    type="number"
                    class="form-control <?php $__errorArgs = ['site_area'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    id="site_area"
                    placeholder="Nhập diện tích tổng thể"
                    value="<?php echo e($project->site_area ?? old('site_area')); ?>"
                    >
                    <?php $__errorArgs = ['site_area'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div id="" class="error invalid-feedback d-block">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-6 form-group">
                    <label for="construction_area">Diện tích xây dựng (<span class="text-red">*</span>)</label>
                    <input
                    name="construction_area"
                    type="number"
                    class="form-control <?php $__errorArgs = ['construction_area'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    id="construction_area"
                    placeholder="Nhập diện tích BDS"
                    value="<?php echo e($project->construction_area ?? old('construction_area')); ?>"
                    >
                    <?php $__errorArgs = ['construction_area'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div id="" class="error invalid-feedback d-block">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

            </div>

            <div class="form-group">
                <label for="investor">Chủ dự án(<span class="text-red">*</span>)</label>
                <input
                name="investor"
                type="text"
                class="form-control <?php $__errorArgs = ['investor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                id="investor"
                placeholder="Chủ dự án"
                value="<?php echo e($project->investor ?? old('investor')); ?>"
                >
                <?php $__errorArgs = ['investor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div id="" class="error invalid-feedback d-block">
                        <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <?php echo $__env->make('admin.pages.project.location_picker', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="row">
                <div class="map-container mx-auto col-12" style="padding:20px">
                    <div id="map" style="width: 100%; height:500px"></div>
                </div>
                <input type="hidden" name="google_map_lat">
                <input type="hidden" name="google_map_lng">
            </div>

            <div class="form-group ">
                <label class="control-label">Mô tả địa điểm</label>
                <?php echo $__env->make('admin.components.ckeditor', ['id' => 'location_description',
                'name' => 'location_description',
                'current_input' => $project->location_description ?? old('location_description') ?? ''
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php $__errorArgs = ['location_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div id="" class="error invalid-feedback d-block">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <!-- /.card-body -->
    </div>

    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Mô tả dự án</h3>
            <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i
                        class="fas fa-minus"></i>
                </button>
            </div>
        </div>
        <div class="card-body">

            <div class="form-group ">
                <label class="control-label">Chính sách ưu đãi</label>
                <?php echo $__env->make('admin.components.ckeditor', ['id' => 'promotion_term',
                'name' => 'promotion_term',
                'current_input' => $project->promotion_term ?? old('promotion_term') ?? ''
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php $__errorArgs = ['promotion_term'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div id="" class="error invalid-feedback d-block">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group ">
                <label class="control-label">Mô tả chi tiết dự án</label>
                <?php echo $__env->make('admin.components.ckeditor', ['id' => 'description',
                'name' => 'description',
                'current_input' => $project->description ?? old('description') ?? ''
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div id="" class="error invalid-feedback d-block">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Quản lý ảnh dự án</h3>
            <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i
                        class="fas fa-minus"></i>
                </button>
            </div>
        </div>
        <div class="card-body">
            <div class="form-group ">
                <label class="control-label">Ảnh slider chính</label>
                <?php echo $__env->make('admin.components.button_file_manager', ['id' => 'overview_image',
                    'input_name' => 'overview_image',
                    'current_input' => $project->overview_image ?? ''
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>

        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Mặt bằng dự án</h3>
            <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i
                        class="fas fa-minus"></i>
                </button>
            </div>
        </div>
        <div class="card-body">
            <?php echo $__env->make('admin.pages.project.ground_editor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>

</div>
<div class="col-md-3">

    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Thao tác</h3>
            <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i
                        class="fas fa-minus"></i>
                </button>
            </div>
        </div>
        <div class="card-body">
            <div class="btn-set">
                <button type="submit" name="submit" value="save" class="btn btn-info">
                    <i class="fa fa-save"></i> Lưu
                </button>
                &nbsp;
                <button type="submit" name="submit" value="apply" class="btn btn-success">
                    <i class="fa fa-check-circle"></i> Lưu &amp; Thoát
                </button>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Trạng thái </h3>
            <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i
                        class="fas fa-minus"></i>
                </button>
            </div>
        </div>

        <div class="card-body">
            <div class="form-group">
                <label>Trạng thái</label>
                <select class="form-control select2 select2-info" value="" name="status" data-dropdown-css-class="select2-info"
                    style="width: 100%;">
                    <?php $__currentLoopData = config('constant.project_status'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index =>  $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($index); ?>" <?php if(isset($project) && $project->status == $index): ?> selected <?php endif; ?> ><?php echo e($item['name'] ?? ''); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Loại dự án</h3>
            <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                    <i class="fas fa-minus"></i>
                </button>
            </div>
        </div>
        <div class="card-body">
            <div class="form-group">
                <label>Loại dự án</label>
                <select class="form-control select2 select2-info" name="project_type" data-dropdown-css-class="select2-info"
                    style="width: 100%;">
                    <?php $__currentLoopData = config('constant.project_type'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($index); ?>" <?php if(isset($project) && $project->project_type == $index): ?> selected <?php endif; ?> ><?php echo e($item['name']); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-group">
                <label class="">Ngày khởi công</label>
                <input
                id="date-picker"
                <?php if(isset($project)): ?>
                value="<?php echo e(Carbon\Carbon::parse( $project->start_time)->format('d/m/Y') ?? ''); ?>"
                <?php endif; ?>
                class="date-picker form-control"
                type="text"
                name="start_time"
                >
                <?php $__errorArgs = ['start_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <label class="">Ngày hoạt động/ dự kiến</label>
                <input
                id="date-picker"
                <?php if(isset($project)): ?>
                value="<?php echo e(Carbon\Carbon::parse( $project->launch_time)->format('d/m/Y') ?? ''); ?>"
                <?php endif; ?>
                class="date-picker form-control"
                type="text"
                name="launch_time"
                >
                <?php $__errorArgs = ['launch_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Ảnh đại diện</h3>
            <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i
                        class="fas fa-minus"></i>
                </button>
            </div>
        </div>
        <div class="card-body">
            <div class="form-group ">
                <label class="control-label">Ảnh đại diện</label>
                <?php echo $__env->make('admin.components.button_file_manager', ['id' => 'avatar',
                    'input_name' => 'avatar',
                    'current_input' => $project->avatar ?? ''
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="form-group ">
                <label class="control-label">Ảnh sơ đồ tổng thể</label>
                <?php echo $__env->make('admin.components.button_file_manager', ['id' => 'overall_diagram',
                    'input_name' => 'overall_diagram',
                    'current_input' => $project->overall_diagram ?? ''
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
</div>

<?php $__env->startSection('css'); ?>
    ##parent-placeholder-2f84417a9e73cead4d5c99e05daff2a534b30132##
    <link rel="stylesheet" href="<?php echo e(asset('template/dropzone-5.7.0/dist/dropzone.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##
    <script src="<?php echo e(asset('template/dropzone-5.7.0/dist/dropzone.js')); ?>"></script>
    <script>
        Dropzone.autoDiscover = false;
        $('#name').on('blur', function () {
            getSlug('project', $(this).val(), $('#slug'));
        });

    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH /home/datnentayninh/domains/datnentayninh.org/public_html/resources/views/admin/pages/project/form.blade.php ENDPATH**/ ?>