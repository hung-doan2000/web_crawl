<div class="modal modal-login fade" id="register" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content px-3 pb-2">
      <div class="modal-body">
        <div class="logo-login text-center">
            <img src="<?php echo e(asset('images/logo.png')); ?>" alt="">
        </div>
        <div class="pt-2 text-center mb-3">
            <strong class="text-blue-dark font-13">Đăng ký tài khoản mới</strong>
        </div>
        <form action="/register" method="POST" id="form-login" class="form-login font-9">
          <?php echo csrf_field(); ?>
          <div class="form-group">
            <div class="bl-div div-fullname">
                <label for="">Họ và tên</label>
              <input type="text" name="register_fullname" id="fullname_register" value="<?php echo e(old('register_fullname')); ?>"  class="form-control font-9" placeholder="Họ và tên" required="required">
              <div class="errors_input text-danger">
                <?php $__errorArgs = ['register_fullname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
          </div>
          <div class="form-group">
            <div class="bl-div div-phone">
                <label for="">Số điện thoại</label>
              <input type="text" name="register_phone_number" class="form-control font-9" value="<?php echo e(old('register_phone_number')); ?>" placeholder="Số điện thoại">
              <div class="errors_input text-danger">
                <?php $__errorArgs = ['register_phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
          </div>
          <div class="form-group">
            <div class="bl-div div-email">
                <label for="">Email</label>
              <input type="email" name="register_email" class="form-control font-9" value="<?php echo e(old('register_email')); ?>" placeholder="Email">
              <div class="errors_input text-danger">
                <?php $__errorArgs = ['register_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
          </div>
          <div class="form-group">
            <div class="bl-div div-password">
                <label for="">Mật khẩu</label>
              <input data-type="password" type="text" name="register_password" value="<?php echo e(old('register_password')); ?>" class="form-control" placeholder="Mật khẩu">
              <span class="span-eyes"></span>
            </div>
            <div class="errors_input text-danger">
              <?php $__errorArgs = ['register_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="form-group">
            <button type="submit" class="btn login-btn w-100" id="register-normal">ĐĂNG KÝ</button>
          </div>
          
        <div class="bl-creat-account font-8 text-center mt-3"><span>Bằng việc đăng ký, bạn đã đồng ý với chúng tôi về </span> <a href="#" class="color-blue">Điều khoản và chính sách</a></div>
        </form>
      </div>
    </div>
  </div>
</div>

<?php $__env->startSection('script'); ?>
  ##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##
  <?php if($errors->has('register_fullname') || $errors->has('register_password') || $errors->has('register_phone_number') || $errors->has('register_email')): ?>
    <script>
      $(document).ready(function(){
        $('#register').modal('toggle')
      });
    </script>
  <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php /**PATH /home/datnentayninh/domains/datnentayninh.org/public_html/resources/views/customer/auth/register.blade.php ENDPATH**/ ?>