<?php $__env->startSection('form'); ?>
<?php echo $__env->make('customer.user_profile.form.account_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('customer.user_profile.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/datnentayninh/domains/datnentayninh.org/public_html/resources/views/customer/user_profile/infomation.blade.php ENDPATH**/ ?>