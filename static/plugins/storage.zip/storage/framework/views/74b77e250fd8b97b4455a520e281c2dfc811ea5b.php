<section class="vertical-advertisment container owl-carousel">
    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="item"><?php echo $ad->content; ?></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</section>
<?php /**PATH /home/datnentayninh/domains/datnentayninh.org/public_html/resources/views/customer/components/advertisments/vertical.blade.php ENDPATH**/ ?>