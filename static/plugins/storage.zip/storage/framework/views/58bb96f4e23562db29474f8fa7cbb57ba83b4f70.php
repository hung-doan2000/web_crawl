<div class="card card-primary card-outline card-outline-tabs">
    <div class="card-header d-flex  align-items-center">
        <h5 class="d-block">Liên hệ</h5>
        <button type="button" class="btnSave ml-auto btn btn-info float-right p-1">Lưu thông tin</button>
    </div>
    <div class="card-body">
        <div class="form-group ">
            <label class="control-label">Chi tiết trang liên hệ</label>
            <?php echo $__env->make('admin.components.ckeditor', ['id' => 'contact_page',
            'name' => 'contact_page',
            'current_input' => $theme_options['contact_page'] ?? ''
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <!-- /.card -->
</div>
<?php /**PATH /home/datnentayninh/domains/datnentayninh.org/public_html/resources/views/admin/pages/theme_options/form/contact.blade.php ENDPATH**/ ?>