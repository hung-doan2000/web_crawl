<?php $__env->startSection('preset_seo'); ?>
    <?php
        $custom_title = $post->name ?? '';
        $custom_description = Str::limit($post->short_description, 200, '...') ?? '';
        $custom_og_image = $post->thumb ?? '';
    ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?><?php echo e($seo->title ?? $post->name); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="single-post hrm-bg-secondary">
	<div class="container pt-3">
        <?php echo e(\App\Helpers\Breadcrumbs\PostBreadcrumbHelper::render($post->categories->first())); ?>


		<div class="row  mt-3">
			<div class="col-md-8 rounded">
                <div class="content bg-white  p-3">
                    <header class="entry-header">
                        <h1 class="font-15 "><?php echo e($post->name ?? ''); ?></h1>
                    </header>
                    <div class="meta-share">
                        <div class="post-meta mb-2 font-9 d-md-flex align-items-center">
                            <?php $__currentLoopData = $post->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a class="label" href="#"><span><?php echo e($item->name); ?></span></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <span class="post-date"> <i class="fa fa-clock-o" aria-hidden="true"></i><?php echo e($date_string); ?></span>
                            <span class="ml-auto">
                                <?php echo $__env->make('customer.components.share_button', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </span>
                        </div>
                        <div class="mb-3" style="font-weight: 500">
                            <?php echo e($post->short_description ?? ''); ?>

                        </div>

                        <div class="post-share">

                        </div>
                    </div>
                    <div class="post-content">
                        <?php echo $post->content; ?>

                    </div>
                </div>

                <div class="blog-post post-related  bg-white mt-3">
                    <h2 class="font-15 p-3 related-title">Các tin liên quan</h2>
                    <div class="list-blog-post list-related">
                        <?php $__currentLoopData = $related_post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="category-blog p-3 rounded-1 bg-white">
                            <div class="top-post row">
                                <div class="col-4 col-md-3 p-0 px-md-3">
                                    <a class="d-block rounded-1 img-wraper pl-2 pl-md-0" href="<?php echo e(route('customer.post.show',['cat_slug' => $post->categories->first()->slug ?? 'danh-muc', 'post_slug' => $post->slug] )); ?>">
                                        <img style="max-height: 175px" class="rounded" src="<?php echo e($post->thumb ?? ''); ?>" alt="<?php echo e($post->name ?? ''); ?>">
                                    </a>
                                </div>
                                <div class="post-link col-8 col-sm-9 pl-md-0 ">
                                    <a style="font-weight: 500" class="font-10 font-md-12 text-dark post-title" href="<?php echo e(route('customer.post.show',['cat_slug' => $post->categories->first()->slug ?? 'danh-muc', 'post_slug' => $post->slug] )); ?>"><?php echo e(Str::limit($post->name, 45, '...')); ?></a>
                                    <div class="mt-2 d-md-block d-none">
                                        <span class="font-9 post-description ">
                                            <?php echo e($post->short_description); ?>

                                        </span>
                                    </div>
                                    <div class="cl-main-text mt-1 font-9 text-muted">
                                        <?php echo e(App\Helpers\TimeHelper::getDateDiffFromNow($post->created_at)['string'] ?? ''); ?> trước
                                    </div>
                                </div>
                            </div>
                        </div>
                        <hr class="my-1">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
			</div>
			<?php echo $__env->make('customer.pages.posts.sidebar', [
                'weekly_news' => $weekly_news,
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    ##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##
    <script>
        maxText($('.blog_excerpt'), 90);

        $('.post-title').each(function(){
            maxText($(this), 60);
        })

        $('.post-description').each(function(){
            maxText($(this), 180);
        })


        function addVisit(type, id){
            $.ajax({
                url: '/api/visit/store',
                type: 'POST',
                data: {
                    type: type,
                    id: id
                }
            })
        }

        $(document).ready(function(){
            addVisit('post', <?php echo e($post->id); ?>);
        })
    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/datnentayninh/domains/datnentayninh.org/public_html/resources/views/customer/pages/posts/show.blade.php ENDPATH**/ ?>